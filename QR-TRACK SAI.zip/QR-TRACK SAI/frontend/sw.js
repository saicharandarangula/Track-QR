'use strict';

/**
 * TrackQR - sw.js (service worker)
 *
 * Rules:
 *  - API calls (/api/...) are NEVER cached and never faked. If the server is down,
 *    the request fails honestly so the app can show its connection error.
 *  - Pages and files use "network first": you always get the newest version when
 *    the server is reachable, and the saved copy is used only when it is not.
 *  - Change CACHE_VERSION whenever you want to force every device to refresh.
 */

const CACHE_VERSION = 'trackqr-v1';

const CORE_FILES = [
  '/',
  '/index.html',
  '/style.css',
  '/script.js',
  '/manifest.json',
  '/icon.svg',
  '/libs/qrcode.min.js',
  '/libs/html5-qrcode.min.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) =>
      // Add files one by one so a missing file never blocks the install
      Promise.allSettled(CORE_FILES.map((url) => cache.add(url)))
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Never touch API traffic
  if (url.pathname.startsWith('/api/')) return;

  event.respondWith(
    fetch(req)
      .then((res) => {
        if (res && res.ok && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(req, copy)).catch(() => {});
        }
        return res;
      })
      .catch(() =>
        caches.match(req).then((cached) => {
          if (cached) return cached;
          if (req.mode === 'navigate') return caches.match('/index.html').then((r) => r || caches.match('/'));
          return new Response('Offline', { status: 503, statusText: 'Offline' });
        })
      )
  );
});