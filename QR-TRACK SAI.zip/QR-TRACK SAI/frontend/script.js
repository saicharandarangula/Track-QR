'use strict';

/* =====================================================================
   TrackQR - script.js
   Frontend logic. Talks to the Express/SQLite backend through /api.
   ===================================================================== */
(function () {

  /* ------------------------------ Helpers ------------------------------ */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  const el = (id) => document.getElementById(id);
  const icon = (n) => '<svg class="icon"><use href="#i-' + n + '"/></svg>';

  function esc(v) {
    return String(v === null || v === undefined ? '' : v).replace(/[&<>"']/g, (c) => (
      { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
  }

  function getApiBase() {
    try {
      const b = localStorage.getItem('trackqr_api_base');
      if (b) return b.replace(/\/+$/, '') + '/api';
    } catch (e) { /* ignore */ }
    return '/api';
  }
  const API = getApiBase();

  const VIEWS = {
    dashboard: 'Dashboard',
    devices: 'Devices',
    stock: 'Stock & Consumables',
    categories: 'Categories',
    maintenance: 'Maintenance',
    scanner: 'QR Scanner',
    logs: 'Activity Logs',
    settings: 'Settings'
  };

  const state = {
    view: 'dashboard',
    online: null,
    booting: false,
    settings: {
      organization_name: 'My Organization', currency: 'INR', default_low_stock: 10,
      scanner_sound: true, scanner_cooldown: 3, auto_open_passport: true, theme: 'light'
    },
    categories: [],
    devices: [],
    stock: [],
    maintenance: [],
    passport: null,
    moveKey: ''
  };

  const seq = { devices: 0, stock: 0, tx: 0, maint: 0, logs: 0 };

  function todayLocal() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  function fmtDateTime(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return esc(iso);
    return d.toLocaleString(undefined, { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  const fmtDate = (d) => (d ? esc(d) : '—');
  const fmtInt = (n) => Number(n || 0).toLocaleString();

  function money(n) {
    try {
      return new Intl.NumberFormat(undefined, { style: 'currency', currency: state.settings.currency || 'INR' }).format(Number(n || 0));
    } catch (e) {
      return String(Number(n || 0).toFixed(2));
    }
  }

  function newKey() {
    if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
    return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 12);
  }

  function debounce(fn, ms) {
    let t;
    return function () {
      const args = arguments;
      clearTimeout(t);
      t = setTimeout(() => fn.apply(null, args), ms);
    };
  }

  /* ------------------------------ Loader + toast ------------------------------ */
  let loaderCount = 0;
  let loaderTimer = null;
  function loaderOn() {
    loaderCount++;
    if (loaderCount === 1) loaderTimer = setTimeout(() => { el('loader').hidden = false; }, 250);
  }
  function loaderOff() {
    loaderCount = Math.max(0, loaderCount - 1);
    if (loaderCount === 0) { clearTimeout(loaderTimer); el('loader').hidden = true; }
  }

  function toast(msg, type, ms) {
    const c = el('toastContainer');
    const t = document.createElement('div');
    t.className = 'toast ' + (type || 'info');
    t.textContent = msg;
    c.appendChild(t);
    setTimeout(() => {
      t.classList.add('out');
      setTimeout(() => t.remove(), 300);
    }, ms || (type === 'error' ? 6000 : 3500));
  }

  /* ------------------------------ API ------------------------------ */
  class ApiError extends Error {
    constructor(message, status, network) {
      super(message);
      this.status = status || 0;
      this.network = !!network;
    }
  }

  function setConnection(ok) {
    const was = state.online;
    state.online = ok;
    el('connBanner').hidden = ok;
    el('serverDot').className = 'status-dot ' + (ok ? 'ok' : 'bad');
    el('serverStatus').textContent = ok ? 'Server connected' : 'Server offline';
    if (ok && was === false) bootData();
  }

  async function api(path, opts) {
    opts = opts || {};
    const silent = !!opts.silent;
    if (!silent) loaderOn();
    try {
      let res;
      try {
        res = await fetch(API + path, {
          method: opts.method || 'GET',
          headers: opts.body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
          body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
          cache: 'no-store'
        });
      } catch (e) {
        setConnection(false);
        throw new ApiError('Cannot reach the TrackQR server. Make sure it is running (npm start).', 0, true);
      }
      setConnection(true);
      let data = null;
      const text = await res.text();
      if (text) { try { data = JSON.parse(text); } catch (e) { data = null; } }
      if (!res.ok) throw new ApiError((data && data.error) || ('Request failed (' + res.status + ').'), res.status);
      return data;
    } finally {
      if (!silent) loaderOff();
    }
  }

  function saveBlob(blob, name) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  async function downloadFrom(path, fallbackName) {
    loaderOn();
    try {
      let res;
      try {
        res = await fetch(API + path, { cache: 'no-store' });
      } catch (e) {
        setConnection(false);
        throw new ApiError('Cannot reach the TrackQR server.', 0, true);
      }
      if (!res.ok) {
        let msg = 'Download failed.';
        try { const j = await res.json(); if (j && j.error) msg = j.error; } catch (e) { /* ignore */ }
        throw new ApiError(msg, res.status);
      }
      const blob = await res.blob();
      let name = fallbackName;
      const cd = res.headers.get('Content-Disposition') || '';
      const m = /filename="?([^";]+)"?/i.exec(cd);
      if (m) name = m[1];
      saveBlob(blob, name);
    } finally {
      loaderOff();
    }
  }

  function handleError(err) {
    if (err && err.network) return; // the red connection banner already explains it
    console.error(err);
    toast((err && err.message) || 'Something went wrong.', 'error');
  }

  /* ------------------------------ Modals ------------------------------ */
  function anyModalOpen() {
    return $$('.modal').some((m) => !m.hidden);
  }
  function syncScrollLock() {
    document.body.classList.toggle('no-scroll', anyModalOpen());
  }
  function openModal(id) {
    el(id).hidden = false;
    syncScrollLock();
    const first = $('input:not([type="hidden"]):not([disabled]), select:not([disabled]), textarea', el(id));
    if (first && window.innerWidth > 640) setTimeout(() => { try { first.focus(); } catch (e) { /* ignore */ } }, 30);
  }
  function closeModal(id) {
    el(id).hidden = true;
    syncScrollLock();
  }
  function setFormError(id, msg) {
    const e = el(id);
    if (!e) return;
    e.textContent = msg || '';
    e.hidden = !msg;
  }

  function confirmDialog(message, opts) {
    opts = opts || {};
    return new Promise((resolve) => {
      el('confirmTitle').textContent = opts.title || 'Please confirm';
      el('confirmMessage').textContent = message;
      const ok = el('confirmOk');
      const cancel = el('confirmCancel');
      ok.textContent = opts.okText || 'Confirm';
      ok.className = 'btn ' + (opts.danger === false ? 'btn-primary' : 'btn-danger');
      const modal = el('confirmModal');
      modal.hidden = false;
      syncScrollLock();
      cancel.focus();
      function done(v) {
        modal.hidden = true;
        ok.removeEventListener('click', onOk);
        cancel.removeEventListener('click', onCancel);
        document.removeEventListener('keydown', onKey, true);
        syncScrollLock();
        resolve(v);
      }
      function onOk() { done(true); }
      function onCancel() { done(false); }
      function onKey(e) {
        if (e.key === 'Escape') { e.stopPropagation(); done(false); }
      }
      ok.addEventListener('click', onOk);
      cancel.addEventListener('click', onCancel);
      document.addEventListener('keydown', onKey, true);
    });
  }

  /* ------------------------------ Badges + tables ------------------------------ */
  const badge = (text, cls) => '<span class="badge badge-' + cls + '">' + esc(text) + '</span>';
  const deviceStatusBadge = (s) => badge(s, { 'Available': 'green', 'In Use': 'blue', 'Under Maintenance': 'amber', 'Retired': 'grey' }[s] || 'grey');
  const conditionBadge = (s) => badge(s, { 'New': 'green', 'Good': 'green', 'Fair': 'amber', 'Poor': 'red', 'Damaged': 'red' }[s] || 'grey');
  const stockLevelBadge = (s) => badge(s, { 'Normal': 'green', 'Low Stock': 'amber', 'Out of Stock': 'red' }[s] || 'grey');
  const maintBadge = (s) => badge(s, { 'Scheduled': 'blue', 'In Progress': 'amber', 'Completed': 'green' }[s] || 'grey');
  const MOVE_LABEL = { IN: 'Stock-In', OUT: 'Stock-Out', RETURN: 'Stock Return' };
  const moveBadge = (t) => badge(MOVE_LABEL[t] || t, { IN: 'green', OUT: 'red', RETURN: 'blue' }[t] || 'grey');

  function actionBtns(list) {
    return '<div class="row-actions">' + list.map((a) =>
      '<button type="button" class="icon-btn' + (a.danger ? ' danger' : '') + '" data-action="' + a.action +
      '" data-id="' + a.id + '" title="' + a.title + '" aria-label="' + a.title + '">' + icon(a.icon) + '</button>'
    ).join('') + '</div>';
  }

  function emptyRow(cols, text) {
    return '<tr><td colspan="' + cols + '" class="empty">' + esc(text) + '</td></tr>';
  }

  function dl(pairs) {
    return '<dl class="detail-grid">' + pairs.map((p) =>
      '<div' + (p[2] ? ' style="grid-column:1/-1"' : '') + '><dt>' + esc(p[0]) + '</dt><dd>' + (p[1] === '' || p[1] === null || p[1] === undefined ? '—' : p[1]) + '</dd></div>'
    ).join('') + '</dl>';
  }

  function miniTable(headers, rows, emptyText) {
    if (!rows.length) return '<p class="muted">' + esc(emptyText) + '</p>';
    return '<div class="table-wrap"><table class="table"><thead><tr>' +
      headers.map((h) => '<th>' + esc(h) + '</th>').join('') + '</tr></thead><tbody>' +
      rows.map((r) => '<tr>' + r.map((c) => '<td>' + c + '</td>').join('') + '</tr>').join('') +
      '</tbody></table></div>';
  }

  /* ------------------------------ Theme + settings ------------------------------ */
  function applyTheme(theme) {
    const t = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', t);
    try { localStorage.setItem('trackqr_theme', t); } catch (e) { /* ignore */ }
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'dark' ? '#0b1220' : '#1d4ed8');
  }

  async function loadSettings() {
    state.settings = await api('/settings', { silent: true });
    applyTheme(state.settings.theme);
    document.title = state.settings.organization_name + ' - TrackQR';
  }

  function fillSettingsForm() {
    const s = state.settings;
    el('setOrgName').value = s.organization_name;
    el('setCurrency').value = s.currency;
    if (el('setCurrency').value !== s.currency) {
      const o = document.createElement('option');
      o.textContent = s.currency;
      el('setCurrency').appendChild(o);
      el('setCurrency').value = s.currency;
    }
    el('setLowStock').value = s.default_low_stock;
    el('setCooldown').value = s.scanner_cooldown;
    el('setTheme').value = s.theme;
    el('setSound').checked = !!s.scanner_sound;
    el('setAutoPassport').checked = !!s.auto_open_passport;
    setFormError('settingsError', '');
    setFormError('restoreError', '');
  }

  async function saveSettings(e) {
    e.preventDefault();
    setFormError('settingsError', '');
    const btn = $('button[type="submit"]', el('settingsForm'));
    if (btn.disabled) return;
    const body = {
      organization_name: el('setOrgName').value.trim(),
      currency: el('setCurrency').value,
      default_low_stock: el('setLowStock').value,
      scanner_cooldown: el('setCooldown').value,
      theme: el('setTheme').value,
      scanner_sound: el('setSound').checked,
      auto_open_passport: el('setAutoPassport').checked
    };
    if (!body.organization_name) { setFormError('settingsError', 'Organization name is required.'); return; }
    btn.disabled = true;
    try {
      state.settings = await api('/settings', { method: 'PUT', body });
      applyTheme(state.settings.theme);
      document.title = state.settings.organization_name + ' - TrackQR';
      fillSettingsForm();
      toast('Settings saved.', 'success');
    } catch (err) {
      setFormError('settingsError', err.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function toggleTheme() {
    const prev = state.settings.theme;
    const next = prev === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try {
      state.settings = await api('/settings', { method: 'PUT', body: { theme: next }, silent: true });
      if (state.view === 'settings') fillSettingsForm();
    } catch (err) {
      applyTheme(prev);
      handleError(err);
    }
  }

  /* ------------------------------ Navigation ------------------------------ */
  function closeSidebar() {
    el('sidebar').classList.remove('open');
    el('sidebarOverlay').classList.remove('show');
  }

  function showView(name) {
    if (!VIEWS[name]) name = 'dashboard';
    if (state.view === 'scanner' && name !== 'scanner') stopScan();
    state.view = name;
    $$('.view').forEach((v) => { v.hidden = v.id !== 'view-' + name; });
    $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === name));
    el('viewTitle').textContent = VIEWS[name];
    try { history.replaceState(null, '', '#' + name); } catch (e) { /* ignore */ }
    closeSidebar();
    window.scrollTo(0, 0);
    loadView(name).catch(handleError);
  }

  async function loadView(name) {
    if (name === 'dashboard') return loadDashboard();
    if (name === 'devices') return loadDevices();
    if (name === 'stock') return Promise.all([loadStock(), loadTransactions()]);
    if (name === 'categories') return loadCategories();
    if (name === 'maintenance') return loadMaintenance();
    if (name === 'logs') return Promise.all([loadLogTypes(), loadLogs()]);
    if (name === 'settings') { fillSettingsForm(); return null; }
    if (name === 'scanner') { setScanStatus(scannerRunning ? 'Scanning...' : 'Camera is off.', ''); return null; }
    return null;
  }

  function refreshCurrentView() {
    return loadView(state.view).catch(handleError);
  }

  async function afterMutation() {
    try { await loadCategories(); } catch (e) { handleError(e); }
    await refreshCurrentView();
  }

  /* ------------------------------ Dashboard ------------------------------ */
  async function loadDashboard() {
    const s = await api('/dashboard/stats');
    el('statTotalDevices').textContent = fmtInt(s.total_devices);
    el('statAvailable').textContent = fmtInt(s.available_devices);
    el('statInUse').textContent = fmtInt(s.in_use_devices);
    el('statMaintenance').textContent = fmtInt(s.maintenance_devices);
    el('statSkus').textContent = fmtInt(s.total_stock_skus);
    el('statUnits').textContent = fmtInt(s.total_stock_units);
    el('statLow').textContent = fmtInt(s.low_stock_alerts);
    el('statOut').textContent = fmtInt(s.out_of_stock_alerts);
    el('statPending').textContent = fmtInt(s.pending_maintenance);

    el('recentActivities').innerHTML = s.recent_activities.length
      ? s.recent_activities.map((a) =>
        '<tr><td class="nowrap">' + fmtDateTime(a.created_at) + '</td><td>' + badge(a.activity_type, 'blue') +
        '</td><td class="wrap-cell">' + esc(a.description) + '</td></tr>').join('')
      : emptyRow(3, 'No activity yet.');

    el('recentTransactions').innerHTML = s.recent_transactions.length
      ? s.recent_transactions.map((t) =>
        '<tr><td class="nowrap">' + fmtDateTime(t.created_at) + '</td><td>' + esc(t.item_name) + '<br><small class="hint mono">' +
        esc(t.stock_id) + '</small></td><td>' + moveBadge(t.movement_type) + '</td><td class="num">' + fmtInt(t.quantity) + '</td></tr>').join('')
      : emptyRow(4, 'No stock movements yet.');
  }

  /* ------------------------------ Categories ------------------------------ */
  function catsOfType(type) {
    return state.categories.filter((c) => c.type === type);
  }

  function fillCategorySelect(select, type, placeholder) {
    const prev = select.value;
    const items = catsOfType(type);
    select.innerHTML = '<option value="">' + esc(placeholder) + '</option>' +
      items.map((c) => '<option value="' + c.id + '">' + esc(c.name) + ' (' + esc(c.prefix) + ')</option>').join('');
    if (Array.from(select.options).some((o) => o.value === prev)) select.value = prev;
  }

  function refreshCategoryDropdowns() {
    fillCategorySelect(el('deviceCategoryFilter'), 'device', 'All categories');
    fillCategorySelect(el('devCategory'), 'device', 'Select a device category');
    fillCategorySelect(el('stockCategoryFilter'), 'stock', 'All categories');
    fillCategorySelect(el('stkCategory'), 'stock', 'Select a stock category');
  }

  function renderCategories() {
    const filter = el('categoryTypeFilter').value;
    const rows = state.categories.filter((c) => !filter || c.type === filter);
    el('categoryTableBody').innerHTML = rows.map((c) =>
      '<tr><td class="mono nowrap">' + esc(c.category_code) + '</td><td class="strong">' + esc(c.name) +
      '</td><td class="mono">' + esc(c.prefix) + '</td><td>' + badge(c.type === 'device' ? 'Device' : 'Stock', c.type === 'device' ? 'blue' : 'green') +
      '</td><td class="wrap-cell">' + esc(c.description) + '</td><td class="num">' + fmtInt(c.item_count) + '</td><td class="actions-col">' +
      actionBtns([
        { action: 'cat-edit', id: c.id, title: 'Edit category', icon: 'edit' },
        { action: 'cat-del', id: c.id, title: 'Delete category', icon: 'trash', danger: true }
      ]) + '</td></tr>').join('');
    el('categoryEmpty').hidden = rows.length > 0;
  }

  async function loadCategories() {
    state.categories = await api('/categories', { silent: true });
    refreshCategoryDropdowns();
    renderCategories();
  }

  function openCategoryModal(cat) {
    setFormError('categoryFormError', '');
    el('categoryForm').reset();
    const typeSel = el('catType');
    if (cat) {
      el('categoryModalTitle').textContent = 'Edit Category';
      el('catId').value = cat.id;
      typeSel.value = cat.type;
      typeSel.disabled = true;
      el('catTypeHint').textContent = 'The type cannot be changed after a category is created.';
      el('catName').value = cat.name;
      el('catPrefix').value = cat.prefix;
      el('catDescription').value = cat.description;
    } else {
      el('categoryModalTitle').textContent = 'Add Category';
      el('catId').value = '';
      typeSel.disabled = false;
      typeSel.value = el('categoryTypeFilter').value || 'device';
      el('catTypeHint').textContent = 'Device categories appear only in Devices. Stock categories appear only in Stock.';
    }
    openModal('categoryModal');
  }

  async function submitCategory(e) {
    e.preventDefault();
    const btn = el('categorySubmit');
    if (btn.disabled) return;
    setFormError('categoryFormError', '');
    const id = el('catId').value;
    const body = {
      name: el('catName').value.trim(),
      prefix: el('catPrefix').value.trim().toUpperCase(),
      description: el('catDescription').value.trim(),
      type: el('catType').value
    };
    if (!body.name) return setFormError('categoryFormError', 'Category name is required.');
    if (!/^[A-Z0-9]{2,6}$/.test(body.prefix)) {
      return setFormError('categoryFormError', 'Prefix must be 2 to 6 letters or numbers (no spaces or symbols).');
    }
    btn.disabled = true;
    try {
      const saved = await api('/categories' + (id ? '/' + id : ''), { method: id ? 'PUT' : 'POST', body });
      closeModal('categoryModal');
      toast('Category "' + saved.name + '" ' + (id ? 'updated.' : 'added.'), 'success');
      await afterMutation();
    } catch (err) {
      setFormError('categoryFormError', err.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function deleteCategory(id) {
    const cat = state.categories.find((c) => String(c.id) === String(id));
    if (!cat) return;
    if (cat.item_count > 0) {
      toast('Cannot delete "' + cat.name + '": ' + cat.item_count + ' item(s) still use it.', 'error');
      return;
    }
    const ok = await confirmDialog('Delete the category "' + cat.name + '"? This cannot be undone.', { title: 'Delete category', okText: 'Delete' });
    if (!ok) return;
    await api('/categories/' + cat.id, { method: 'DELETE' });
    toast('Category deleted.', 'success');
    await afterMutation();
  }

  /* ------------------------------ Devices ------------------------------ */
  function deviceParams() {
    const p = new URLSearchParams();
    const q = el('deviceSearch').value.trim();
    if (q) p.set('q', q);
    if (el('deviceCategoryFilter').value) p.set('category_id', el('deviceCategoryFilter').value);
    if (el('deviceStatusFilter').value) p.set('status', el('deviceStatusFilter').value);
    if (el('deviceConditionFilter').value) p.set('condition', el('deviceConditionFilter').value);
    const s = el('deviceSort').value.split(':');
    p.set('sort', s[0]);
    p.set('order', s[1]);
    return p.toString();
  }

  async function loadDevices() {
    const my = ++seq.devices;
    const data = await api('/devices?' + deviceParams());
    if (my !== seq.devices) return;
    state.devices = data;
    el('deviceTableBody').innerHTML = data.map((d) =>
      '<tr><td class="mono nowrap">' + esc(d.asset_id) + '</td><td class="strong">' + esc(d.name) +
      ((d.brand || d.model) ? '<br><small class="hint">' + esc((d.brand + ' ' + d.model).trim()) + '</small>' : '') +
      '</td><td>' + esc(d.category_name) + '</td><td>' + (esc(d.serial_number) || '—') + '</td><td>' + (esc(d.location) || '—') +
      '</td><td>' + (esc(d.assigned_to) || '—') + '</td><td>' + conditionBadge(d.condition) + '</td><td>' + deviceStatusBadge(d.status) +
      '</td><td class="actions-col">' + actionBtns([
        { action: 'dev-view', id: d.id, title: 'View details', icon: 'eye' },
        { action: 'dev-qr', id: d.id, title: 'QR Passport', icon: 'qr' },
        { action: 'dev-edit', id: d.id, title: 'Edit device', icon: 'edit' },
        { action: 'dev-del', id: d.id, title: 'Delete device', icon: 'trash', danger: true }
      ]) + '</td></tr>').join('');
    el('deviceEmpty').hidden = data.length > 0;
  }

  function openDeviceModal(d) {
    setFormError('deviceFormError', '');
    el('deviceForm').reset();
    refreshCategoryDropdowns();
    if (d) {
      el('deviceModalTitle').textContent = 'Edit Device ' + d.asset_id;
      el('devId').value = d.id;
      el('devName').value = d.name;
      el('devCategory').value = String(d.category_id);
      el('devSerial').value = d.serial_number;
      el('devBrand').value = d.brand;
      el('devModel').value = d.model;
      el('devPurchaseDate').value = d.purchase_date;
      el('devPrice').value = d.purchase_price;
      el('devLocation').value = d.location;
      el('devAssigned').value = d.assigned_to;
      el('devCondition').value = d.condition;
      el('devStatus').value = d.status;
      el('devDescription').value = d.description;
    } else {
      el('deviceModalTitle').textContent = 'Add Device';
      el('devId').value = '';
      el('devCondition').value = 'Good';
      el('devStatus').value = 'Available';
      if (catsOfType('device').length === 0) {
        setFormError('deviceFormError', 'There are no device categories yet. Please add one in the Categories page first.');
      }
    }
    openModal('deviceModal');
  }

  async function submitDevice(e) {
    e.preventDefault();
    const btn = el('deviceSubmit');
    if (btn.disabled) return;
    setFormError('deviceFormError', '');
    const id = el('devId').value;
    const body = {
      name: el('devName').value.trim(),
      category_id: el('devCategory').value,
      serial_number: el('devSerial').value.trim(),
      brand: el('devBrand').value.trim(),
      model: el('devModel').value.trim(),
      purchase_date: el('devPurchaseDate').value,
      purchase_price: el('devPrice').value,
      location: el('devLocation').value.trim(),
      assigned_to: el('devAssigned').value.trim(),
      condition: el('devCondition').value,
      status: el('devStatus').value,
      description: el('devDescription').value.trim()
    };
    if (!body.name) return setFormError('deviceFormError', 'Device name is required.');
    if (!body.category_id) return setFormError('deviceFormError', 'Please choose a category.');
    if (body.purchase_price !== '' && Number(body.purchase_price) < 0) return setFormError('deviceFormError', 'Purchase price cannot be negative.');
    btn.disabled = true;
    try {
      const saved = await api('/devices' + (id ? '/' + id : ''), { method: id ? 'PUT' : 'POST', body });
      closeModal('deviceModal');
      toast('Device ' + saved.asset_id + (id ? ' updated.' : ' registered.'), 'success');
      await afterMutation();
      if (!id && state.settings.auto_open_passport) openPassport('device', saved);
    } catch (err) {
      setFormError('deviceFormError', err.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function fetchDevice(id) {
    return api('/devices/' + id);
  }

  async function viewDevice(id) {
    const d = await fetchDevice(id);
    el('detailTitle').textContent = d.asset_id + ' - ' + d.name;
    el('detailBody').innerHTML =
      dl([
        ['Asset ID', '<span class="mono">' + esc(d.asset_id) + '</span>'],
        ['Device name', esc(d.name)],
        ['Category', esc(d.category_name)],
        ['Serial number', esc(d.serial_number)],
        ['Brand', esc(d.brand)],
        ['Model', esc(d.model)],
        ['Purchase date', fmtDate(d.purchase_date)],
        ['Purchase price', money(d.purchase_price)],
        ['Location', esc(d.location)],
        ['Assigned to', esc(d.assigned_to)],
        ['Condition', conditionBadge(d.condition)],
        ['Status', deviceStatusBadge(d.status)],
        ['Description', esc(d.description), true],
        ['Registered', fmtDateTime(d.created_at)],
        ['Last updated', fmtDateTime(d.updated_at)]
      ]) +
      '<div class="detail-section"><h3>Maintenance history</h3>' +
      miniTable(['Ticket', 'Type', 'Scheduled', 'Completed', 'Status'],
        d.maintenance_history.map((m) => [esc(m.ticket_id), esc(m.maintenance_type), fmtDate(m.scheduled_date), fmtDate(m.completion_date), maintBadge(m.status)]),
        'No maintenance recorded for this device.') + '</div>' +
      '<div class="detail-section"><h3>Device history</h3>' +
      miniTable(['Date', 'Activity', 'Description'],
        d.activity_history.map((a) => [fmtDateTime(a.created_at), esc(a.activity_type), esc(a.description)]),
        'No history yet.') + '</div>';
    el('detailActions').innerHTML =
      '<button type="button" class="btn btn-outline" data-action="dev-qr" data-id="' + d.id + '">' + icon('qr') + 'QR Passport</button>' +
      '<button type="button" class="btn btn-outline" data-action="dev-edit" data-id="' + d.id + '">' + icon('edit') + 'Edit</button>' +
      '<button type="button" class="btn btn-primary" data-close>Close</button>';
    openModal('detailModal');
  }

  async function deleteDevice(id) {
    const d = state.devices.find((x) => String(x.id) === String(id)) || await fetchDevice(id);
    const ok = await confirmDialog('Delete device ' + d.asset_id + ' (' + d.name + ')? The device record will be removed, but its history stays in the Activity Logs.', { title: 'Delete device', okText: 'Delete' });
    if (!ok) return;
    await api('/devices/' + id, { method: 'DELETE' });
    toast('Device deleted.', 'success');
    await afterMutation();
  }

  /* ------------------------------ Stock ------------------------------ */
  function stockParams() {
    const p = new URLSearchParams();
    const q = el('stockSearch').value.trim();
    if (q) p.set('q', q);
    if (el('stockCategoryFilter').value) p.set('category_id', el('stockCategoryFilter').value);
    if (el('stockLevelFilter').value) p.set('level', el('stockLevelFilter').value);
    const s = el('stockSort').value.split(':');
    p.set('sort', s[0]);
    p.set('order', s[1]);
    return p.toString();
  }

  async function loadStock() {
    const my = ++seq.stock;
    const data = await api('/stock?' + stockParams());
    if (my !== seq.stock) return;
    state.stock = data;
    el('stockTableBody').innerHTML = data.map((s) =>
      '<tr><td class="mono nowrap">' + esc(s.stock_id) + '</td><td class="strong">' + esc(s.name) + '</td><td>' + esc(s.category_name) +
      '</td><td class="num">' + fmtInt(s.quantity) + ' ' + esc(s.unit) + '</td><td class="num">' + fmtInt(s.min_stock_level) +
      '</td><td class="num">' + money(s.unit_price) + '</td><td>' + stockLevelBadge(s.stock_level) + '</td><td>' + (esc(s.location) || '—') +
      '</td><td class="actions-col">' + actionBtns([
        { action: 'stk-move', id: s.id, title: 'Stock movement', icon: 'refresh' },
        { action: 'stk-view', id: s.id, title: 'View details', icon: 'eye' },
        { action: 'stk-qr', id: s.id, title: 'QR Passport', icon: 'qr' },
        { action: 'stk-edit', id: s.id, title: 'Edit stock item', icon: 'edit' },
        { action: 'stk-del', id: s.id, title: 'Delete stock item', icon: 'trash', danger: true }
      ]) + '</td></tr>').join('');
    el('stockEmpty').hidden = data.length > 0;
  }

  async function loadTransactions() {
    const my = ++seq.tx;
    const data = await api('/stock/transactions?limit=200');
    if (my !== seq.tx) return;
    el('transactionTableBody').innerHTML = data.map((t) =>
      '<tr><td class="mono nowrap">' + esc(t.transaction_id) + '</td><td class="nowrap">' + fmtDateTime(t.created_at) + '</td><td>' + esc(t.item_name) +
      '<br><small class="hint mono">' + esc(t.stock_id) + '</small></td><td>' + moveBadge(t.movement_type) + '</td><td class="num">' + fmtInt(t.quantity) +
      '</td><td class="num">' + fmtInt(t.balance_after) + '</td><td>' + (esc(t.person) || '—') + '</td><td class="wrap-cell">' + (esc(t.remarks) || '—') + '</td></tr>').join('');
    el('transactionEmpty').hidden = data.length > 0;
  }

  function openStockModal(s) {
    setFormError('stockFormError', '');
    el('stockForm').reset();
    refreshCategoryDropdowns();
    if (s) {
      el('stockModalTitle').textContent = 'Edit Stock Item ' + s.stock_id;
      el('stkId').value = s.id;
      el('stkName').value = s.name;
      el('stkCategory').value = String(s.category_id);
      el('stkQuantity').value = s.quantity;
      el('stkQuantity').disabled = true;
      el('stkQuantityHint').textContent = 'Change the quantity using Stock-In, Stock-Out or Stock Return so every change is recorded.';
      el('stkUnit').value = s.unit;
      el('stkPrice').value = s.unit_price;
      el('stkMin').value = s.min_stock_level;
      el('stkLocation').value = s.location;
      el('stkSupplier').value = s.supplier;
      el('stkDescription').value = s.description;
    } else {
      el('stockModalTitle').textContent = 'Add Stock Item';
      el('stkId').value = '';
      el('stkQuantity').disabled = false;
      el('stkQuantity').value = 0;
      el('stkQuantityHint').textContent = 'Opening quantity.';
      el('stkUnit').value = 'pcs';
      el('stkPrice').value = 0;
      el('stkMin').value = state.settings.default_low_stock;
      if (catsOfType('stock').length === 0) {
        setFormError('stockFormError', 'There are no stock categories yet. Please add one in the Categories page first.');
      }
    }
    openModal('stockModal');
  }

  async function submitStock(e) {
    e.preventDefault();
    const btn = el('stockSubmit');
    if (btn.disabled) return;
    setFormError('stockFormError', '');
    const id = el('stkId').value;
    const body = {
      name: el('stkName').value.trim(),
      category_id: el('stkCategory').value,
      description: el('stkDescription').value.trim(),
      unit: el('stkUnit').value.trim() || 'pcs',
      unit_price: el('stkPrice').value,
      min_stock_level: el('stkMin').value,
      location: el('stkLocation').value.trim(),
      supplier: el('stkSupplier').value.trim()
    };
    if (!id) body.quantity = el('stkQuantity').value;
    if (!body.name) return setFormError('stockFormError', 'Item name is required.');
    if (!body.category_id) return setFormError('stockFormError', 'Please choose a category.');
    if (!id && (body.quantity === '' || !Number.isInteger(Number(body.quantity)) || Number(body.quantity) < 0)) {
      return setFormError('stockFormError', 'Quantity must be a whole number, 0 or more.');
    }
    if (body.min_stock_level !== '' && (!Number.isInteger(Number(body.min_stock_level)) || Number(body.min_stock_level) < 0)) {
      return setFormError('stockFormError', 'Minimum stock level must be a whole number, 0 or more.');
    }
    if (body.unit_price !== '' && Number(body.unit_price) < 0) return setFormError('stockFormError', 'Unit price cannot be negative.');
    btn.disabled = true;
    try {
      const saved = await api('/stock' + (id ? '/' + id : ''), { method: id ? 'PUT' : 'POST', body });
      closeModal('stockModal');
      toast('Stock item ' + saved.stock_id + (id ? ' updated.' : ' created.'), 'success');
      await afterMutation();
      if (!id && state.settings.auto_open_passport) openPassport('stock', saved);
    } catch (err) {
      setFormError('stockFormError', err.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function fetchStock(id) {
    return api('/stock/' + id);
  }

  async function viewStock(id) {
    const s = await fetchStock(id);
    el('detailTitle').textContent = s.stock_id + ' - ' + s.name;
    el('detailBody').innerHTML =
      dl([
        ['Stock ID', '<span class="mono">' + esc(s.stock_id) + '</span>'],
        ['Item name', esc(s.name)],
        ['Category', esc(s.category_name)],
        ['Quantity', fmtInt(s.quantity) + ' ' + esc(s.unit)],
        ['Minimum stock level', fmtInt(s.min_stock_level)],
        ['Stock level', stockLevelBadge(s.stock_level)],
        ['Unit price', money(s.unit_price)],
        ['Total value', money(s.unit_price * s.quantity)],
        ['Location', esc(s.location)],
        ['Supplier', esc(s.supplier)],
        ['Description', esc(s.description), true],
        ['Last updated', fmtDateTime(s.updated_at)]
      ]) +
      '<div class="detail-section"><h3>Transaction history</h3>' +
      miniTable(['Date', 'Type', 'Qty', 'Balance', 'Person', 'Remarks'],
        s.transactions.map((t) => [fmtDateTime(t.created_at), moveBadge(t.movement_type), fmtInt(t.quantity), fmtInt(t.balance_after), esc(t.person), esc(t.remarks)]),
        'No movements recorded yet.') + '</div>';
    el('detailActions').innerHTML =
      '<button type="button" class="btn btn-outline" data-action="stk-move" data-id="' + s.id + '">' + icon('refresh') + 'Stock Movement</button>' +
      '<button type="button" class="btn btn-outline" data-action="stk-qr" data-id="' + s.id + '">' + icon('qr') + 'QR Passport</button>' +
      '<button type="button" class="btn btn-outline" data-action="stk-edit" data-id="' + s.id + '">' + icon('edit') + 'Edit</button>' +
      '<button type="button" class="btn btn-primary" data-close>Close</button>';
    openModal('detailModal');
  }

  async function deleteStock(id) {
    const s = state.stock.find((x) => String(x.id) === String(id)) || await fetchStock(id);
    const ok = await confirmDialog('Delete stock item ' + s.stock_id + ' (' + s.name + ')? Its transaction history will be kept in the records.', { title: 'Delete stock item', okText: 'Delete' });
    if (!ok) return;
    await api('/stock/' + id, { method: 'DELETE' });
    toast('Stock item deleted.', 'success');
    await afterMutation();
  }

  async function openMoveModal(id) {
    const s = state.stock.find((x) => String(x.id) === String(id)) || await fetchStock(id);
    setFormError('moveFormError', '');
    el('moveForm').reset();
    el('mvId').value = s.id;
    el('mvType').value = 'IN';
    state.moveKey = newKey();
    el('moveItemInfo').innerHTML = '<strong>' + esc(s.name) + '</strong> (<span class="mono">' + esc(s.stock_id) + '</span>)<br>Current balance: <strong>' +
      fmtInt(s.quantity) + ' ' + esc(s.unit) + '</strong>';
    openModal('moveModal');
  }

  async function submitMove(e) {
    e.preventDefault();
    const btn = el('moveSubmit');
    if (btn.disabled) return;
    setFormError('moveFormError', '');
    const id = el('mvId').value;
    const qty = el('mvQuantity').value;
    const person = el('mvPerson').value.trim();
    if (qty === '' || !Number.isInteger(Number(qty)) || Number(qty) < 1) {
      return setFormError('moveFormError', 'Quantity must be a whole number of 1 or more.');
    }
    if (!person) return setFormError('moveFormError', 'Person responsible is required.');
    btn.disabled = true;
    try {
      const r = await api('/stock/' + id + '/movement', {
        method: 'POST',
        body: { type: el('mvType').value, quantity: Number(qty), person, remarks: el('mvRemarks').value.trim(), request_key: state.moveKey }
      });
      closeModal('moveModal');
      state.moveKey = '';
      if (r.duplicate) toast('This movement was already recorded.', 'info');
      else toast(MOVE_LABEL[r.transaction.movement_type] + ' saved. New balance: ' + fmtInt(r.item.quantity) + ' ' + r.item.unit, 'success');
      await afterMutation();
    } catch (err) {
      setFormError('moveFormError', err.message);
    } finally {
      btn.disabled = false;
    }
  }

  /* ------------------------------ Maintenance ------------------------------ */
  async function loadMaintenance() {
    const my = ++seq.maint;
    const p = new URLSearchParams();
    if (el('maintSearch').value.trim()) p.set('q', el('maintSearch').value.trim());
    if (el('maintStatusFilter').value) p.set('status', el('maintStatusFilter').value);
    const data = await api('/maintenance?' + p.toString());
    if (my !== seq.maint) return;
    state.maintenance = data;
    el('maintTableBody').innerHTML = data.map((m) =>
      '<tr><td class="mono nowrap">' + esc(m.ticket_id) + '</td><td class="strong">' + esc(m.device_name) + '<br><small class="hint mono">' + esc(m.device_asset_id) +
      '</small></td><td>' + esc(m.maintenance_type) + '</td><td class="nowrap">' + fmtDate(m.scheduled_date) + '</td><td class="nowrap">' + fmtDate(m.completion_date) +
      '</td><td>' + (esc(m.technician) || '—') + '</td><td class="num">' + money(m.cost) + '</td><td>' + maintBadge(m.status) + '</td><td class="actions-col">' +
      actionBtns([
        { action: 'mnt-edit', id: m.id, title: 'Edit ticket', icon: 'edit' },
        { action: 'mnt-del', id: m.id, title: 'Delete ticket', icon: 'trash', danger: true }
      ]) + '</td></tr>').join('');
    el('maintEmpty').hidden = data.length > 0;
  }

  function syncCompletionField() {
    const done = el('mntStatus').value === 'Completed';
    el('mntCompletion').disabled = !done;
    if (!done) el('mntCompletion').value = '';
    else if (!el('mntCompletion').value) el('mntCompletion').value = todayLocal();
  }

  async function openMaintModal(m) {
    setFormError('maintFormError', '');
    el('maintForm').reset();
    const devices = await api('/devices?sort=asset_id&order=asc');
    const sel = el('mntDevice');
    sel.innerHTML = '<option value="">Select a device</option>' +
      devices.map((d) => '<option value="' + d.id + '">' + esc(d.asset_id) + ' - ' + esc(d.name) + '</option>').join('');
    if (m) {
      el('maintModalTitle').textContent = 'Edit Ticket ' + m.ticket_id;
      el('mntId').value = m.id;
      if (m.device_id && !devices.some((d) => d.id === m.device_id)) {
        sel.insertAdjacentHTML('beforeend', '<option value="' + m.device_id + '">' + esc(m.device_asset_id) + ' - ' + esc(m.device_name) + '</option>');
      }
      if (!m.device_id) {
        sel.innerHTML = '<option value="">' + esc(m.device_asset_id + ' - ' + m.device_name + ' (deleted device)') + '</option>';
      } else {
        sel.value = String(m.device_id);
      }
      sel.disabled = true;
      el('mntType').value = m.maintenance_type;
      el('mntScheduled').value = m.scheduled_date;
      el('mntCompletion').value = m.completion_date;
      el('mntTechnician').value = m.technician;
      el('mntCost').value = m.cost;
      el('mntStatus').value = m.status;
      el('mntNotes').value = m.notes;
    } else {
      el('maintModalTitle').textContent = 'New Maintenance Ticket';
      el('mntId').value = '';
      sel.disabled = false;
      el('mntType').value = 'Repair';
      el('mntScheduled').value = todayLocal();
      el('mntCost').value = 0;
      el('mntStatus').value = 'Scheduled';
      if (devices.length === 0) setFormError('maintFormError', 'There are no devices yet. Please add a device first.');
    }
    syncCompletionField();
    openModal('maintModal');
  }

  async function submitMaint(e) {
    e.preventDefault();
    const btn = el('maintSubmit');
    if (btn.disabled) return;
    setFormError('maintFormError', '');
    const id = el('mntId').value;
    const body = {
      device_id: el('mntDevice').value,
      maintenance_type: el('mntType').value,
      scheduled_date: el('mntScheduled').value,
      completion_date: el('mntCompletion').value,
      technician: el('mntTechnician').value.trim(),
      cost: el('mntCost').value,
      status: el('mntStatus').value,
      notes: el('mntNotes').value.trim()
    };
    if (!id && !body.device_id) return setFormError('maintFormError', 'Please select a device.');
    if (body.cost !== '' && Number(body.cost) < 0) return setFormError('maintFormError', 'Cost cannot be negative.');
    btn.disabled = true;
    try {
      const saved = await api('/maintenance' + (id ? '/' + id : ''), { method: id ? 'PUT' : 'POST', body });
      closeModal('maintModal');
      toast('Ticket ' + saved.ticket_id + (id ? ' updated.' : ' created.'), 'success');
      await afterMutation();
    } catch (err) {
      setFormError('maintFormError', err.message);
    } finally {
      btn.disabled = false;
    }
  }

  async function deleteMaint(id) {
    const m = state.maintenance.find((x) => String(x.id) === String(id));
    if (!m) return;
    const ok = await confirmDialog('Delete maintenance ticket ' + m.ticket_id + ' for ' + m.device_asset_id + '?', { title: 'Delete ticket', okText: 'Delete' });
    if (!ok) return;
    await api('/maintenance/' + id, { method: 'DELETE' });
    toast('Ticket deleted.', 'success');
    await afterMutation();
  }

  /* ------------------------------ Logs ------------------------------ */
  function logParams() {
    const p = new URLSearchParams();
    if (el('logSearch').value.trim()) p.set('q', el('logSearch').value.trim());
    if (el('logTypeFilter').value) p.set('type', el('logTypeFilter').value);
    if (el('logFrom').value) p.set('from', el('logFrom').value);
    if (el('logTo').value) p.set('to', el('logTo').value);
    return p.toString();
  }

  async function loadLogTypes() {
    const types = await api('/logs/types', { silent: true });
    const sel = el('logTypeFilter');
    const prev = sel.value;
    sel.innerHTML = '<option value="">All activities</option>' + types.map((t) => '<option>' + esc(t) + '</option>').join('');
    if (types.includes(prev)) sel.value = prev;
  }

  async function loadLogs() {
    const my = ++seq.logs;
    const data = await api('/logs?limit=500&' + logParams());
    if (my !== seq.logs) return;
    el('logTableBody').innerHTML = data.map((l) =>
      '<tr><td class="nowrap">' + fmtDateTime(l.created_at) + '</td><td>' + badge(l.activity_type, 'blue') + '</td><td class="wrap-cell">' + esc(l.description) +
      '</td><td class="mono">' + (esc(l.item_code) || '—') + '</td><td>' + esc(l.user_name) + '</td></tr>').join('');
    el('logEmpty').hidden = data.length > 0;
  }

  /* ------------------------------ QR Passport ------------------------------ */
  function makeQr(container, text) {
    container.innerHTML = '';
    if (typeof QRCode === 'undefined') {
      container.innerHTML = '<p class="form-error">The QR library file (libs/qrcode.min.js) is not installed yet.</p>';
      return false;
    }
    /* eslint-disable-next-line no-new */
    new QRCode(container, { text, width: 512, height: 512, colorDark: '#000000', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.H });
    return true;
  }

  async function openPassport(type, item) {
    if (!item.qr_payload) {
      item = type === 'device' ? await fetchDevice(item.id) : await fetchStock(item.id);
    }
    const isDevice = type === 'device';
    const code = isDevice ? item.asset_id : item.stock_id;
    state.passport = {
      type, code, name: item.name, category: item.category_name,
      serial: isDevice ? (item.serial_number || '') : null, payload: item.qr_payload
    };
    el('ppOrg').textContent = state.settings.organization_name;
    el('ppType').textContent = isDevice ? 'Device' : 'Stock Item';
    el('ppId').textContent = code;
    el('ppName').textContent = item.name;
    el('ppCategory').textContent = item.category_name;
    el('ppSerialRow').hidden = !isDevice;
    el('ppSerial').textContent = isDevice ? (item.serial_number || '—') : '';
    const ok = makeQr(el('ppQr'), item.qr_payload);
    el('btnPpDownload').disabled = !ok;
    el('btnPpPrint').disabled = !ok;
    el('passportTitle').textContent = 'QR Passport - ' + code;
    openModal('passportModal');
  }

  function fitText(ctx, text, maxW, startPx, weight, family) {
    let px = startPx;
    do {
      ctx.font = weight + ' ' + px + 'px ' + family;
      px -= 2;
    } while (ctx.measureText(text).width > maxW && px > 16);
    return text;
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function downloadPassportPng() {
    const p = state.passport;
    if (!p) return;
    const src = $('canvas', el('ppQr')) || $('img', el('ppQr'));
    if (!src) { toast('The QR code is not ready.', 'error'); return; }
    const W = 900;
    const H = 1320;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d');
    const sans = '"Segoe UI", Arial, sans-serif';
    const mono = 'Consolas, "Courier New", monospace';
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, W, H);
    ctx.lineWidth = 10;
    ctx.strokeStyle = '#1d4ed8';
    roundRect(ctx, 15, 15, W - 30, H - 30, 40);
    ctx.stroke();
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';

    ctx.fillStyle = '#1d4ed8';
    fitText(ctx, state.settings.organization_name, W - 140, 52, '800', sans);
    ctx.fillText(state.settings.organization_name, W / 2, 105);

    const label = (p.type === 'device' ? 'DEVICE' : 'STOCK ITEM');
    ctx.font = '700 30px ' + sans;
    const bw = ctx.measureText(label).width + 80;
    ctx.fillStyle = '#1d4ed8';
    roundRect(ctx, (W - bw) / 2, 140, bw, 56, 28);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.fillText(label, W / 2, 180);

    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(src, (W - 600) / 2, 235, 600, 600);

    ctx.fillStyle = '#0f172a';
    fitText(ctx, p.code, W - 120, 78, '800', mono);
    ctx.fillText(p.code, W / 2, 940);

    fitText(ctx, p.name, W - 120, 48, '600', sans);
    ctx.fillText(p.name, W / 2, 1015);

    ctx.fillStyle = '#475569';
    fitText(ctx, 'Category: ' + p.category, W - 120, 36, '500', sans);
    ctx.fillText('Category: ' + p.category, W / 2, 1085);
    if (p.serial !== null) {
      const sr = 'Serial No.: ' + (p.serial || '—');
      fitText(ctx, sr, W - 120, 36, '500', sans);
      ctx.fillText(sr, W / 2, 1140);
    }
    ctx.fillStyle = '#94a3b8';
    ctx.font = '500 26px ' + sans;
    ctx.fillText('Scan with TrackQR', W / 2, 1240);

    c.toBlob((blob) => {
      if (!blob) { toast('Could not create the PNG.', 'error'); return; }
      saveBlob(blob, p.code + '-QR.png');
    }, 'image/png');
  }

  /* ------------------------------ Scanner ------------------------------ */
  let scanner = null;
  let scannerRunning = false;
  let cameras = [];
  let cameraIndex = 0;
  let lastScan = { code: '', time: 0 };
  let lookupBusy = false;
  let audioCtx = null;

  function setScanStatus(msg, cls) {
    const s = el('scanStatus');
    s.textContent = msg;
    s.className = 'scan-status' + (cls ? ' ' + cls : '');
  }

  function setScannerButtons() {
    el('btnStartScan').disabled = scannerRunning;
    el('btnStopScan').disabled = !scannerRunning;
    el('btnSwitchCamera').disabled = !scannerRunning || cameras.length < 2;
    el('scannerPlaceholder').hidden = scannerRunning;
  }

  function beep() {
    if (!state.settings.scanner_sound) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      audioCtx = audioCtx || new AC();
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'sine';
      o.frequency.value = 880;
      g.gain.value = 0.15;
      o.connect(g);
      g.connect(audioCtx.destination);
      o.start();
      o.stop(audioCtx.currentTime + 0.12);
    } catch (e) { /* ignore */ }
  }

  async function startScan() {
    if (typeof Html5Qrcode === 'undefined') {
      setScanStatus('The scanner library (libs/html5-qrcode.min.js) is not installed yet.', 'bad');
      return;
    }
    if (!window.isSecureContext) {
      setScanStatus('The camera only works on https:// or http://localhost.', 'bad');
      return;
    }
    if (scannerRunning) return;
    el('btnStartScan').disabled = true;
    setScanStatus('Requesting camera permission...', '');
    try {
      if (!scanner) scanner = new Html5Qrcode('scannerReader');
      if (cameras.length === 0) {
        cameras = await Html5Qrcode.getCameras();
        const back = cameras.findIndex((c) => /back|rear|environment/i.test(c.label || ''));
        cameraIndex = back >= 0 ? back : 0;
      }
      if (!cameras.length) throw new Error('No camera was found on this device.');
      await scanner.start(cameras[cameraIndex].id, { fps: 10, qrbox: { width: 240, height: 240 } }, onScanSuccess, () => {});
      scannerRunning = true;
      setScanStatus('Scanning... point the camera at a TrackQR code.', 'ok');
    } catch (err) {
      scannerRunning = false;
      const m = String((err && err.message) || err || '');
      if (/permission|denied|NotAllowed/i.test(m)) {
        setScanStatus('Camera permission was denied. Allow the camera in your browser settings and try again.', 'bad');
      } else if (/NotFound|No camera/i.test(m)) {
        setScanStatus('No camera was found on this device.', 'bad');
      } else if (/NotReadable|in use/i.test(m)) {
        setScanStatus('The camera is being used by another app. Close it and try again.', 'bad');
      } else {
        setScanStatus('Could not start the camera: ' + m, 'bad');
      }
    }
    setScannerButtons();
  }

  async function stopScan() {
    if (scanner && scannerRunning) {
      try { await scanner.stop(); } catch (e) { /* ignore */ }
      try { scanner.clear(); } catch (e) { /* ignore */ }
    }
    scannerRunning = false;
    setScannerButtons();
    if (state.view === 'scanner') setScanStatus('Camera is off.', '');
  }

  async function switchCamera() {
    if (cameras.length < 2) return;
    await stopScan();
    cameraIndex = (cameraIndex + 1) % cameras.length;
    await startScan();
  }

  function onScanSuccess(text) {
    const now = Date.now();
    const cooldown = Number(state.settings.scanner_cooldown || 0) * 1000;
    if (anyModalOpen() || lookupBusy) return;
    if (lastScan.code === text && now - lastScan.time < cooldown) return;
    lastScan = { code: text, time: now };
    beep();
    handleScannedCode(text, true);
  }

  function showScanResult(r) {
    const it = r.item;
    const isDevice = r.type === 'device';
    const code = isDevice ? it.asset_id : it.stock_id;
    el('scanResult').innerHTML =
      '<div class="result-card">' + badge(isDevice ? 'Device' : 'Stock Item', isDevice ? 'blue' : 'green') +
      '<h3>' + esc(it.name) + '</h3><div class="mono">' + esc(code) + '</div><div class="muted">' + esc(it.category_name) + '</div>' +
      '<div class="btn-row">' +
      '<button type="button" class="btn btn-primary btn-sm" data-action="' + (isDevice ? 'dev-view' : 'stk-view') + '" data-id="' + it.id + '">View details</button>' +
      '<button type="button" class="btn btn-outline btn-sm" data-action="' + (isDevice ? 'dev-qr' : 'stk-qr') + '" data-id="' + it.id + '">QR Passport</button>' +
      (isDevice ? '' : '<button type="button" class="btn btn-outline btn-sm" data-action="stk-move" data-id="' + it.id + '">Stock movement</button>') +
      '</div></div>';
  }

  function showScanError(msg) {
    el('scanResult').innerHTML = '<div class="result-card bad">' + esc(msg) + '</div>';
    setScanStatus(msg, 'bad');
    toast(msg, 'error');
  }

  async function handleScannedCode(code, fromCamera) {
    if (lookupBusy) return;
    lookupBusy = true;
    try {
      const r = await api('/qr/lookup/' + encodeURIComponent(String(code).trim()), { silent: !!fromCamera });
      showScanResult(r);
      setScanStatus('Found ' + (r.type === 'device' ? 'device ' + r.item.asset_id : 'stock item ' + r.item.stock_id) + '.', 'ok');
      if (r.type === 'device') await viewDevice(r.item.id);
      else await viewStock(r.item.id);
    } catch (err) {
      if (err.network) return;
      showScanError(err.status === 404 ? 'This QR code is not recognised by TrackQR.' : err.message);
    } finally {
      lookupBusy = false;
    }
  }

  async function scanImageFile(file) {
    if (!file) return;
    if (!/^image\/(png|jpe?g|webp|gif)$/i.test(file.type)) { toast('Please choose a PNG, JPG, WEBP or GIF image.', 'error'); return; }
    if (file.size > 10 * 1024 * 1024) { toast('The image is too large (maximum 10 MB).', 'error'); return; }
    if (typeof Html5Qrcode === 'undefined') {
      showScanError('The scanner library (libs/html5-qrcode.min.js) is not installed yet.');
      return;
    }
    let holder = el('qrFileHolder');
    if (!holder) {
      holder = document.createElement('div');
      holder.id = 'qrFileHolder';
      holder.style.display = 'none';
      document.body.appendChild(holder);
    }
    const reader = new Html5Qrcode('qrFileHolder');
    let text = '';
    try {
      text = await reader.scanFile(file, false);
    } catch (e) {
      showScanError('No QR code could be read from this image. Try a clearer, larger picture.');
      return;
    } finally {
      try { reader.clear(); } catch (e) { /* ignore */ }
    }
    beep();
    await handleScannedCode(text, false);
  }

  /* ------------------------------ Backup / restore ------------------------------ */
  async function restoreFromFile(file) {
    setFormError('restoreError', '');
    if (!file) return;
    if (file.size > 24 * 1024 * 1024) return setFormError('restoreError', 'This file is too large to be a TrackQR backup.');
    let data;
    try {
      data = JSON.parse(await file.text());
    } catch (e) {
      return setFormError('restoreError', 'This file is not valid JSON, so it cannot be a TrackQR backup.');
    }
    if (!data || data.app !== 'TrackQR' || !data.tables) {
      return setFormError('restoreError', 'This is not a TrackQR backup file.');
    }
    const ok = await confirmDialog('Restoring will REPLACE ALL current devices, stock, categories, maintenance, logs and settings with the contents of this backup. This cannot be undone. Continue?',
      { title: 'Restore backup', okText: 'Replace all data' });
    if (!ok) return;
    try {
      await api('/backup/restore', { method: 'POST', body: { confirm: true, backup: data } });
      toast('Backup restored successfully.', 'success');
      await loadSettings();
      fillSettingsForm();
      await afterMutation();
    } catch (err) {
      setFormError('restoreError', err.message);
    }
  }

  /* ------------------------------ Boot ------------------------------ */
  async function bootData() {
    if (state.booting) return;
    state.booting = true;
    try {
      await loadSettings();
      await loadCategories();
      await loadView(state.view);
    } catch (err) {
      handleError(err);
    } finally {
      state.booting = false;
    }
  }

  async function pingServer() {
    try {
      await api('/health', { silent: true });
    } catch (e) { /* api() already updated the connection state */ }
  }

  /* ------------------------------ Events ------------------------------ */
  function wire() {
    /* Navigation */
    $$('.nav-item').forEach((b) => b.addEventListener('click', () => showView(b.dataset.view)));
    el('btnMenu').addEventListener('click', () => {
      el('sidebar').classList.add('open');
      el('sidebarOverlay').classList.add('show');
    });
    el('sidebarOverlay').addEventListener('click', closeSidebar);
    el('btnQuickScan').addEventListener('click', () => showView('scanner'));
    el('btnTheme').addEventListener('click', () => toggleTheme());
    el('btnRetryConn').addEventListener('click', () => { pingServer(); });

    /* Delegated clicks: [data-close], [data-go], [data-action] */
    document.addEventListener('click', (e) => {
      const closer = e.target.closest('[data-close]');
      if (closer) {
        const modal = closer.closest('.modal');
        if (modal) closeModal(modal.id);
        return;
      }
      const go = e.target.closest('[data-go]');
      if (go) { showView(go.dataset.go); return; }
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const id = btn.dataset.id;
      const action = btn.dataset.action;
      if (!$('#detailModal').hidden && action !== 'noop') closeModal('detailModal');
      runAction(action, id).catch(handleError);
    });

    /* Close modals by clicking the dark backdrop (only if the press also started there) */
    let downOnBackdrop = null;
    document.addEventListener('mousedown', (e) => { downOnBackdrop = e.target.classList && e.target.classList.contains('modal') ? e.target : null; });
    document.addEventListener('click', (e) => {
      const t = e.target;
      if (t.classList && t.classList.contains('modal') && t === downOnBackdrop && t.id !== 'confirmModal') closeModal(t.id);
    });
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape') return;
      if (!el('confirmModal').hidden) return;
      const open = $$('.modal').filter((m) => !m.hidden);
      if (open.length) closeModal(open[open.length - 1].id);
    });

    /* Categories */
    el('btnAddCategory').addEventListener('click', () => openCategoryModal(null));
    el('categoryForm').addEventListener('submit', submitCategory);
    el('categoryTypeFilter').addEventListener('change', renderCategories);
    el('btnExportCategories').addEventListener('click', () => {
      const t = el('categoryTypeFilter').value;
      downloadFrom('/export/categories' + (t ? '?type=' + t : ''), 'trackqr-categories.csv').catch(handleError);
    });
    el('catPrefix').addEventListener('input', (e) => {
      e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    });

    /* Devices */
    el('btnAddDevice').addEventListener('click', () => openDeviceModal(null));
    el('deviceForm').addEventListener('submit', submitDevice);
    el('deviceSearch').addEventListener('input', debounce(() => loadDevices().catch(handleError), 300));
    ['deviceCategoryFilter', 'deviceStatusFilter', 'deviceConditionFilter', 'deviceSort'].forEach((id) =>
      el(id).addEventListener('change', () => loadDevices().catch(handleError)));
    el('btnExportDevices').addEventListener('click', () => downloadFrom('/export/devices?' + deviceParams(), 'trackqr-devices.csv').catch(handleError));

    /* Stock */
    el('btnAddStock').addEventListener('click', () => openStockModal(null));
    el('stockForm').addEventListener('submit', submitStock);
    el('moveForm').addEventListener('submit', submitMove);
    el('stockSearch').addEventListener('input', debounce(() => loadStock().catch(handleError), 300));
    ['stockCategoryFilter', 'stockLevelFilter', 'stockSort'].forEach((id) =>
      el(id).addEventListener('change', () => loadStock().catch(handleError)));
    el('btnExportStock').addEventListener('click', () => downloadFrom('/export/stock?' + stockParams(), 'trackqr-stock.csv').catch(handleError));
    el('btnExportTransactions').addEventListener('click', () => downloadFrom('/export/transactions', 'trackqr-transactions.csv').catch(handleError));

    /* Maintenance */
    el('btnAddMaint').addEventListener('click', () => openMaintModal(null).catch(handleError));
    el('maintForm').addEventListener('submit', submitMaint);
    el('mntStatus').addEventListener('change', syncCompletionField);
    el('maintSearch').addEventListener('input', debounce(() => loadMaintenance().catch(handleError), 300));
    el('maintStatusFilter').addEventListener('change', () => loadMaintenance().catch(handleError));
    el('btnExportMaint').addEventListener('click', () => {
      const p = new URLSearchParams();
      if (el('maintStatusFilter').value) p.set('status', el('maintStatusFilter').value);
      if (el('maintSearch').value.trim()) p.set('q', el('maintSearch').value.trim());
      downloadFrom('/export/maintenance?' + p.toString(), 'trackqr-maintenance.csv').catch(handleError);
    });

    /* Logs */
    el('logSearch').addEventListener('input', debounce(() => loadLogs().catch(handleError), 300));
    ['logTypeFilter', 'logFrom', 'logTo'].forEach((id) => el(id).addEventListener('change', () => loadLogs().catch(handleError)));
    el('btnExportLogs').addEventListener('click', () => downloadFrom('/export/logs?' + logParams(), 'trackqr-logs.csv').catch(handleError));

    /* Settings + backup */
    el('settingsForm').addEventListener('submit', saveSettings);
    el('btnBackupExport').addEventListener('click', () => downloadFrom('/backup/export', 'trackqr-backup.json').then(() => toast('Backup downloaded.', 'success')).catch(handleError));
    el('btnBackupRestore').addEventListener('click', () => { el('restoreFile').value = ''; el('restoreFile').click(); });
    el('restoreFile').addEventListener('change', (e) => { restoreFromFile(e.target.files[0]).catch(handleError); });

    /* Passport */
    el('btnPpDownload').addEventListener('click', downloadPassportPng);
    el('btnPpPrint').addEventListener('click', () => window.print());

    /* Scanner */
    el('btnStartScan').addEventListener('click', () => startScan());
    el('btnStopScan').addEventListener('click', () => stopScan());
    el('btnSwitchCamera').addEventListener('click', () => switchCamera());
    el('btnManualLookup').addEventListener('click', () => {
      const v = el('manualCode').value.trim();
      if (!v) { toast('Type a code first, for example LAP-0001.', 'error'); return; }
      handleScannedCode(v, false);
    });
    el('manualCode').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); el('btnManualLookup').click(); } });
    el('scanFile').addEventListener('change', (e) => { const f = e.target.files[0]; e.target.value = ''; scanImageFile(f); });
    const dz = el('dropZone');
    ['dragenter', 'dragover'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add('drag'); }));
    ['dragleave', 'drop'].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove('drag'); }));
    dz.addEventListener('drop', (e) => { const f = e.dataTransfer && e.dataTransfer.files[0]; scanImageFile(f); });
    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', (e) => e.preventDefault());
  }

  async function runAction(action, id) {
    switch (action) {
      case 'cat-edit': return openCategoryModal(state.categories.find((c) => String(c.id) === String(id)));
      case 'cat-del': return deleteCategory(id);
      case 'dev-view': return viewDevice(id);
      case 'dev-qr': return openPassport('device', state.devices.find((d) => String(d.id) === String(id)) || await fetchDevice(id));
      case 'dev-edit': return openDeviceModal(state.devices.find((d) => String(d.id) === String(id)) || await fetchDevice(id));
      case 'dev-del': return deleteDevice(id);
      case 'stk-view': return viewStock(id);
      case 'stk-qr': return openPassport('stock', state.stock.find((s) => String(s.id) === String(id)) || await fetchStock(id));
      case 'stk-edit': return openStockModal(state.stock.find((s) => String(s.id) === String(id)) || await fetchStock(id));
      case 'stk-del': return deleteStock(id);
      case 'stk-move': return openMoveModal(id);
      case 'mnt-edit': return openMaintModal(state.maintenance.find((m) => String(m.id) === String(id))).catch(handleError);
      case 'mnt-del': return deleteMaint(id);
      default: return null;
    }
  }

  /* ------------------------------ Start ------------------------------ */
  function init() {
    try { applyTheme(localStorage.getItem('trackqr_theme') || 'light'); } catch (e) { applyTheme('light'); }
    wire();
    setScannerButtons();
    const hash = (location.hash || '').replace('#', '');
    state.view = VIEWS[hash] ? hash : 'dashboard';
    $$('.view').forEach((v) => { v.hidden = v.id !== 'view-' + state.view; });
    $$('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === state.view));
    el('viewTitle').textContent = VIEWS[state.view];
    bootData();
    setInterval(pingServer, 30000);
  }

  window.addEventListener('unhandledrejection', (e) => {
    const r = e.reason;
    if (r && r.network) { e.preventDefault(); return; }
    console.error('Unhandled error:', r);
  });

  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
  }

  init();
})();