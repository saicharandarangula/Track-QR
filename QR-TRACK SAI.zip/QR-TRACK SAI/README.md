# TrackQR - QR-Based Inventory & Asset Tracker

A web app for tracking hardware devices and consumable stock with unique QR codes.
Frontend: HTML, CSS, JavaScript. Backend: Node.js + Express. Database: SQLite.

## 1. Folder structure

```
QR-TRACK SAI/
├── package.json
├── .env
├── README.md
├── backend/
│   ├── server.js        (web server + REST API + serves the frontend)
│   ├── database.js      (SQLite tables, rules, backup/restore)
│   └── data/
│       └── inventory.db (your data - created automatically)
└── frontend/
    ├── index.html
    ├── style.css
    ├── script.js
    ├── manifest.json
    ├── sw.js
    ├── icon.svg
    └── libs/
        ├── qrcode.min.js
        └── html5-qrcode.min.js
```

## 2. First-time setup

1. Install Node.js (LTS version) from https://nodejs.org
2. Open the project folder in VS Code (File > Open Folder > QR-TRACK SAI).
3. Open the terminal (Ctrl + `) and run:

```
npm install
```

## 3. Start the app

```
npm start
```

Then open http://localhost:5000 in your browser.
Stop the server with Ctrl + C.

Do NOT use VS Code Live Server. The backend serves the frontend itself.

## 4. Quick API checks

Open these in your browser while the server is running:

- http://localhost:5000/api/health
- http://localhost:5000/api/dashboard/stats
- http://localhost:5000/api/categories
- http://localhost:5000/api/devices
- http://localhost:5000/api/stock
- http://localhost:5000/api/maintenance
- http://localhost:5000/api/logs
- http://localhost:5000/api/settings
- http://localhost:5000/api/qr/lookup/LAP-0001
- http://localhost:5000/api/backup/export

## 5. Your data

All records are stored in `backend/data/inventory.db`.
Data stays after you refresh the browser or restart the server.

Make backups regularly: Settings > Export Backup (saves a JSON file).
Restore: Settings > Restore From Backup (replaces ALL current data after confirmation).

To start again with an empty database: stop the server, delete
`backend/data/inventory.db` (and the `inventory.db-wal` / `inventory.db-shm`
files if present), then run `npm start`. This permanently erases everything.

## 6. How IDs and QR codes work

- Every device and stock item gets a permanent unique ID built from its category
  prefix, for example LAP-0001 or CAB-0003.
- Numbers are never reused, even after a deletion.
- The QR code contains `TQR:D:<asset id>` for devices and `TQR:S:<stock id>`
  for stock items. Scanning looks the code up in the database.
- Changing a category prefix affects NEW items only. Existing IDs never change.

## 7. Troubleshooting

**"NetworkError when attempting to fetch resource" / red connection banner**
1. Is the server running? Run `npm start` in the project folder.
2. Are you on http://localhost:5000 (not a file:// address, not Live Server)?
3. Open http://localhost:5000/api/health. It must show "status":"ok".

**Port 5000 already in use**
Another copy is running. Close the other terminal (Ctrl + C), or change PORT in `.env`.

**Cannot find module 'better-sqlite3' or NODE_MODULE_VERSION error**
Run `npm install` in the top-level folder. If it still fails, install the Node.js LTS version, delete the `node_modules` folder and `package-lock.json`, then run `npm install` again.

**Page looks old after changing a file**
Press Ctrl + F5. If it persists: F12 > Application > Service workers > Unregister, then Clear site data.

**Camera does not start**
Use http://localhost:5000 (the camera needs localhost or HTTPS). Allow the camera in the browser's address bar. Close other apps that use the camera.

## 8. Installing as an app (PWA)

Open http://localhost:5000 in Chrome or Edge and use the install icon in the address bar.
On a phone, the app must be served over HTTPS (see section 9).

## 9. Future: Android app and Google Play

IMPORTANT: TrackQR is NOT Play Store ready yet. Do not claim it is until every
step below is completed and tested.

An installed Android app cannot use `localhost:5000`. The backend must first be
deployed to a public HTTPS server.

### Step A - Deploy the backend
1. Choose a host that can run Node.js and keeps a persistent disk for the SQLite
   file (a small VPS, Render with a disk, Railway with a volume, etc.).
2. Copy the project, run `npm install --omit=dev`, set `NODE_ENV=production`, and run `npm start`.
3. Put it behind HTTPS (most hosts provide this).
4. Set `CORS_ORIGINS` in the host's environment settings if the frontend will be served from another address.
5. Back up `backend/data/inventory.db` regularly.

### Step B - Add login BEFORE going public
TrackQR currently has no user accounts. Anyone who can reach a public server
could read and change the data. Add authentication (login, password hashing,
sessions or tokens) before exposing the server to the internet.

### Step C - Point the app at the public server
The frontend currently calls the same address it was loaded from (`/api`).
For an installed Android app, a configurable server address must be added
to `script.js` (it already supports a stored `trackqr_api_base` value for this).

### Step D - Wrap with Capacitor
```
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init TrackQR com.yourcompany.trackqr --web-dir=frontend
npx cap add android
npx cap sync android
npx cap open android
```
Android Studio opens. Add the CAMERA permission to AndroidManifest.xml.

### Step E - Build a signed App Bundle (.aab)
1. In Android Studio: Build > Generate Signed Bundle / APK > Android App Bundle.
2. Create a new keystore (keep the keystore file and passwords safe and backed
   up - losing them means you cannot update the app).
3. Choose the "release" build and finish. The .aab file is produced.

### Step F - Google Play Console
1. Create a Google Play developer account (one-time registration fee).
2. Create the app, complete the store listing (icon, screenshots, description).
3. Provide a privacy policy URL and complete the Data safety form.
4. Upload the .aab to an Internal or Closed testing track first.
5. New personal developer accounts may need a closed test with a minimum number of
   testers for a minimum period before production access. Check the current
   requirements in Play Console.
6. Fix any problems found in testing, then submit for production review.

## 10. Security notes

- No secrets are stored in the code. Settings live in `.env`.
- All database queries use parameters, and all input is validated on the server.
- Do not upload `.env` or `inventory.db` to a public place.