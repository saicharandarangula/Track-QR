 'use strict';

/**
 * TrackQR - database.js
 * Creates the SQLite database, all tables, constraints, indexes,
 * default settings/categories, and helper functions used by server.js.
 */

const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });
const Database = require('better-sqlite3');

/* ------------------------------------------------------------------ */
/* Error type used for friendly (safe) messages sent to the browser    */
/* ------------------------------------------------------------------ */
class AppError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.name = 'AppError';
    this.status = status;
  }
}

/* ------------------------------------------------------------------ */
/* Open database                                                       */
/* ------------------------------------------------------------------ */
const dbFile = path.resolve(__dirname, '..', process.env.DB_FILE || 'backend/data/inventory.db');
fs.mkdirSync(path.dirname(dbFile), { recursive: true });

const db = new Database(dbFile);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

/* ------------------------------------------------------------------ */
/* Tables                                                              */
/* ------------------------------------------------------------------ */
db.exec(`
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS id_counters (
  type        TEXT NOT NULL,
  prefix      TEXT NOT NULL,
  last_number INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (type, prefix)
);

CREATE TABLE IF NOT EXISTS categories (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  category_code TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL COLLATE NOCASE,
  prefix        TEXT NOT NULL COLLATE NOCASE,
  description   TEXT NOT NULL DEFAULT '',
  type          TEXT NOT NULL CHECK (type IN ('device','stock')),
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  updated_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  UNIQUE (type, name),
  UNIQUE (type, prefix),
  CHECK (length(trim(name)) > 0),
  CHECK (length(prefix) BETWEEN 2 AND 6)
);

CREATE TABLE IF NOT EXISTS devices (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  asset_id       TEXT NOT NULL UNIQUE,
  name           TEXT NOT NULL CHECK (length(trim(name)) > 0),
  category_id    INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  serial_number  TEXT NOT NULL DEFAULT '',
  brand          TEXT NOT NULL DEFAULT '',
  model          TEXT NOT NULL DEFAULT '',
  purchase_date  TEXT NOT NULL DEFAULT '',
  purchase_price REAL NOT NULL DEFAULT 0 CHECK (purchase_price >= 0),
  location       TEXT NOT NULL DEFAULT '',
  assigned_to    TEXT NOT NULL DEFAULT '',
  condition      TEXT NOT NULL DEFAULT 'Good' CHECK (condition IN ('New','Good','Fair','Poor','Damaged')),
  status         TEXT NOT NULL DEFAULT 'Available' CHECK (status IN ('Available','In Use','Under Maintenance','Retired')),
  description    TEXT NOT NULL DEFAULT '',
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

CREATE TABLE IF NOT EXISTS stock_items (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  stock_id        TEXT NOT NULL UNIQUE,
  name            TEXT NOT NULL CHECK (length(trim(name)) > 0),
  category_id     INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT ON UPDATE CASCADE,
  description     TEXT NOT NULL DEFAULT '',
  quantity        INTEGER NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  unit            TEXT NOT NULL DEFAULT 'pcs',
  unit_price      REAL NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
  min_stock_level INTEGER NOT NULL DEFAULT 0 CHECK (min_stock_level >= 0),
  location        TEXT NOT NULL DEFAULT '',
  supplier        TEXT NOT NULL DEFAULT '',
  created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

CREATE TABLE IF NOT EXISTS stock_transactions (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  transaction_id TEXT NOT NULL UNIQUE,
  stock_item_id  INTEGER REFERENCES stock_items(id) ON DELETE SET NULL,
  stock_id       TEXT NOT NULL,
  item_name      TEXT NOT NULL,
  movement_type  TEXT NOT NULL CHECK (movement_type IN ('IN','OUT','RETURN')),
  quantity       INTEGER NOT NULL CHECK (quantity > 0),
  balance_after  INTEGER NOT NULL CHECK (balance_after >= 0),
  person         TEXT NOT NULL DEFAULT '',
  remarks        TEXT NOT NULL DEFAULT '',
  request_key    TEXT UNIQUE,
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

CREATE TABLE IF NOT EXISTS maintenance (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id        TEXT NOT NULL UNIQUE,
  device_id        INTEGER REFERENCES devices(id) ON DELETE SET NULL,
  device_asset_id  TEXT NOT NULL,
  device_name      TEXT NOT NULL,
  maintenance_type TEXT NOT NULL DEFAULT 'Repair',
  scheduled_date   TEXT NOT NULL DEFAULT '',
  completion_date  TEXT NOT NULL DEFAULT '',
  technician       TEXT NOT NULL DEFAULT '',
  cost             REAL NOT NULL DEFAULT 0 CHECK (cost >= 0),
  notes            TEXT NOT NULL DEFAULT '',
  status           TEXT NOT NULL DEFAULT 'Scheduled' CHECK (status IN ('Scheduled','In Progress','Completed')),
  created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  updated_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

CREATE TABLE IF NOT EXISTS activity_logs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  activity_type TEXT NOT NULL,
  description   TEXT NOT NULL,
  item_type     TEXT NOT NULL DEFAULT 'system',
  item_code     TEXT NOT NULL DEFAULT '',
  user_name     TEXT NOT NULL DEFAULT 'Admin',
  created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);

/* Indexes */
CREATE UNIQUE INDEX IF NOT EXISTS idx_devices_serial
  ON devices (serial_number COLLATE NOCASE) WHERE serial_number <> '';
CREATE INDEX IF NOT EXISTS idx_devices_category ON devices (category_id);
CREATE INDEX IF NOT EXISTS idx_devices_status   ON devices (status);
CREATE INDEX IF NOT EXISTS idx_stock_category   ON stock_items (category_id);
CREATE INDEX IF NOT EXISTS idx_txn_stock        ON stock_transactions (stock_item_id);
CREATE INDEX IF NOT EXISTS idx_txn_created      ON stock_transactions (created_at);
CREATE INDEX IF NOT EXISTS idx_maint_device     ON maintenance (device_id);
CREATE INDEX IF NOT EXISTS idx_maint_status     ON maintenance (status);
CREATE INDEX IF NOT EXISTS idx_logs_created     ON activity_logs (created_at);
CREATE INDEX IF NOT EXISTS idx_logs_type        ON activity_logs (activity_type);

/* Category rules enforced by the database itself */
CREATE TRIGGER IF NOT EXISTS trg_devices_cat_type_ins
BEFORE INSERT ON devices
WHEN (SELECT type FROM categories WHERE id = NEW.category_id) <> 'device'
BEGIN SELECT RAISE(ABORT, 'A device must use a device category'); END;

CREATE TRIGGER IF NOT EXISTS trg_devices_cat_type_upd
BEFORE UPDATE OF category_id ON devices
WHEN (SELECT type FROM categories WHERE id = NEW.category_id) <> 'device'
BEGIN SELECT RAISE(ABORT, 'A device must use a device category'); END;

CREATE TRIGGER IF NOT EXISTS trg_stock_cat_type_ins
BEFORE INSERT ON stock_items
WHEN (SELECT type FROM categories WHERE id = NEW.category_id) <> 'stock'
BEGIN SELECT RAISE(ABORT, 'A stock item must use a stock category'); END;

CREATE TRIGGER IF NOT EXISTS trg_stock_cat_type_upd
BEFORE UPDATE OF category_id ON stock_items
WHEN (SELECT type FROM categories WHERE id = NEW.category_id) <> 'stock'
BEGIN SELECT RAISE(ABORT, 'A stock item must use a stock category'); END;

CREATE TRIGGER IF NOT EXISTS trg_categories_type_locked
BEFORE UPDATE OF type ON categories
WHEN NEW.type <> OLD.type
BEGIN SELECT RAISE(ABORT, 'Category type cannot be changed'); END;
`);

/* ------------------------------------------------------------------ */
/* Small helpers                                                       */
/* ------------------------------------------------------------------ */
function nowIso() {
  return new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
}

const counterStmt = db.prepare(`
  INSERT INTO id_counters (type, prefix, last_number) VALUES (?, ?, 1)
  ON CONFLICT (type, prefix) DO UPDATE SET last_number = last_number + 1
  RETURNING last_number
`);

/** Creates a permanent unique ID such as LAP-0001. Numbers never repeat. */
function generateId(type, prefix) {
  const row = counterStmt.get(type, String(prefix).toUpperCase());
  return `${String(prefix).toUpperCase()}-${String(row.last_number).padStart(4, '0')}`;
}

const insertLogStmt = db.prepare(`
  INSERT INTO activity_logs (activity_type, description, item_type, item_code, user_name)
  VALUES (?, ?, ?, ?, ?)
`);

function logActivity({ type, description, itemType = 'system', itemCode = '', user = 'Admin' }) {
  insertLogStmt.run(type, description, itemType, itemCode || '', user);
}

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */
const DEFAULT_SETTINGS = {
  organization_name: 'My Organization',
  currency: 'INR',
  default_low_stock: '10',
  scanner_sound: 'true',
  scanner_cooldown: '3',
  auto_open_passport: 'true',
  theme: 'light'
};

function ensureDefaultSettings() {
  const stmt = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) stmt.run(k, v);
}

function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const map = {};
  rows.forEach((r) => { map[r.key] = r.value; });
  const get = (k) => (map[k] !== undefined ? map[k] : DEFAULT_SETTINGS[k]);
  return {
    organization_name: get('organization_name'),
    currency: get('currency'),
    default_low_stock: Number(get('default_low_stock')),
    scanner_sound: get('scanner_sound') === 'true',
    scanner_cooldown: Number(get('scanner_cooldown')),
    auto_open_passport: get('auto_open_passport') === 'true',
    theme: get('theme')
  };
}

function toBool(v, label) {
  if (v === true || v === 'true') return 'true';
  if (v === false || v === 'false') return 'false';
  throw new AppError(`${label} must be true or false.`);
}

function toIntInRange(v, min, max, label) {
  if (v === '' || v === null || v === undefined) throw new AppError(`${label} is required.`);
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new AppError(`${label} must be a whole number between ${min} and ${max}.`);
  }
  return String(n);
}

function updateSettings(input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new AppError('Invalid settings data.');
  }
  const clean = {};

  if ('organization_name' in input) {
    const v = String(input.organization_name || '').trim();
    if (!v) throw new AppError('Organization name is required.');
    if (v.length > 100) throw new AppError('Organization name must be 100 characters or fewer.');
    clean.organization_name = v;
  }
  if ('currency' in input) {
    const v = String(input.currency || '').trim().toUpperCase();
    if (!/^[A-Z]{3}$/.test(v)) throw new AppError('Currency must be a 3-letter code such as INR or USD.');
    clean.currency = v;
  }
  if ('default_low_stock' in input) {
    clean.default_low_stock = toIntInRange(input.default_low_stock, 0, 100000, 'Default low stock level');
  }
  if ('scanner_cooldown' in input) {
    clean.scanner_cooldown = toIntInRange(input.scanner_cooldown, 0, 60, 'Scanner cooldown');
  }
  if ('scanner_sound' in input) clean.scanner_sound = toBool(input.scanner_sound, 'Scanner sound');
  if ('auto_open_passport' in input) clean.auto_open_passport = toBool(input.auto_open_passport, 'Automatic QR Passport opening');
  if ('theme' in input) {
    if (!['light', 'dark'].includes(input.theme)) throw new AppError('Theme must be light or dark.');
    clean.theme = input.theme;
  }

  const save = db.transaction(() => {
    const stmt = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
    for (const [k, v] of Object.entries(clean)) stmt.run(k, v);
  });
  save();
  return getSettings();
}

/* ------------------------------------------------------------------ */
/* Default categories (only the very first time the database is made)  */
/* ------------------------------------------------------------------ */
function seedDefaults() {
  const flag = db.prepare("SELECT value FROM settings WHERE key = 'defaults_seeded'").get();
  if (flag) return;

  const deviceCats = [
    ['Laptop', 'LAP', 'Laptop computers'],
    ['Desktop', 'DSK', 'Desktop computers'],
    ['Printer', 'PRN', 'Printers and scanners'],
    ['Network Equipment', 'NET', 'Routers, switches and access points'],
    ['Mobile Device', 'MOB', 'Phones and tablets'],
    ['Peripheral', 'PER', 'Monitors, keyboards, mice and similar']
  ];
  const stockCats = [
    ['Cables', 'CAB', 'Cables and connectors'],
    ['Toner & Ink', 'INK', 'Printer toner and ink cartridges'],
    ['Stationery', 'STA', 'Paper, pens and office supplies'],
    ['Accessories', 'ACC', 'General accessories']
  ];

  const seed = db.transaction(() => {
    const count = db.prepare('SELECT COUNT(*) AS c FROM categories').get().c;
    if (count === 0) {
      const ins = db.prepare(
        'INSERT INTO categories (category_code, name, prefix, description, type) VALUES (?, ?, ?, ?, ?)'
      );
      deviceCats.forEach(([n, p, d]) => ins.run(generateId('category', 'CAT'), n, p, d, 'device'));
      stockCats.forEach(([n, p, d]) => ins.run(generateId('category', 'CAT'), n, p, d, 'stock'));
    }
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('defaults_seeded', '1')").run();
  });
  seed();
}

/* ------------------------------------------------------------------ */
/* Backup and restore                                                  */
/* ------------------------------------------------------------------ */
const BACKUP_TABLES = [
  'settings',
  'id_counters',
  'categories',
  'devices',
  'stock_items',
  'stock_transactions',
  'maintenance',
  'activity_logs'
];

function exportBackup() {
  const tables = {};
  BACKUP_TABLES.forEach((t) => {
    tables[t] = db.prepare(`SELECT * FROM ${t}`).all();
  });
  return {
    app: 'TrackQR',
    backup_version: 1,
    exported_at: new Date().toISOString(),
    tables
  };
}

function validateBackup(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new AppError('This is not a valid TrackQR backup file.');
  }
  if (data.app !== 'TrackQR') throw new AppError('This file was not created by TrackQR.');
  if (data.backup_version !== 1) throw new AppError('This backup version is not supported.');
  if (!data.tables || typeof data.tables !== 'object') {
    throw new AppError('The backup file has no data tables.');
  }
  BACKUP_TABLES.forEach((t) => {
    const rows = data.tables[t];
    if (!Array.isArray(rows)) throw new AppError(`The backup file is missing the "${t}" data.`);
    rows.forEach((row, i) => {
      if (!row || typeof row !== 'object' || Array.isArray(row)) {
        throw new AppError(`Row ${i + 1} in "${t}" is invalid.`);
      }
      Object.values(row).forEach((v) => {
        if (v !== null && typeof v !== 'string' && typeof v !== 'number') {
          throw new AppError(`Row ${i + 1} in "${t}" contains an invalid value.`);
        }
      });
    });
  });
}

function restoreBackup(data) {
  validateBackup(data);

  const stmtCache = new Map();
  const tableColumns = {};
  BACKUP_TABLES.forEach((t) => {
    tableColumns[t] = db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
  });

  const run = db.transaction(() => {
    [...BACKUP_TABLES].reverse().forEach((t) => db.prepare(`DELETE FROM ${t}`).run());

    BACKUP_TABLES.forEach((t) => {
      data.tables[t].forEach((row, i) => {
        const keys = Object.keys(row).filter((k) => tableColumns[t].includes(k));
        if (keys.length === 0) throw new AppError(`Row ${i + 1} in "${t}" is invalid.`);
        const cacheKey = `${t}|${keys.join(',')}`;
        let stmt = stmtCache.get(cacheKey);
        if (!stmt) {
          stmt = db.prepare(
            `INSERT INTO ${t} (${keys.map((k) => `"${k}"`).join(',')}) VALUES (${keys.map(() => '?').join(',')})`
          );
          stmtCache.set(cacheKey, stmt);
        }
        stmt.run(keys.map((k) => row[k]));
      });
    });

    ensureDefaultSettings();
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('defaults_seeded', '1')").run();

    const broken = db.prepare('PRAGMA foreign_key_check').all();
    if (broken.length > 0) throw new AppError('The backup file has inconsistent data links.');
  });

  try {
    run();
  } catch (err) {
    if (err instanceof AppError) throw err;
    console.error('Restore failed:', err.message);
    throw new AppError('The backup file is invalid or inconsistent. No changes were made.');
  }

  const counts = {};
  BACKUP_TABLES.forEach((t) => { counts[t] = data.tables[t].length; });
  return counts;
}

/* ------------------------------------------------------------------ */
/* Initialise                                                          */
/* ------------------------------------------------------------------ */
ensureDefaultSettings();
seedDefaults();

module.exports = {
  db,
  dbFile,
  AppError,
  nowIso,
  generateId,
  logActivity,
  getSettings,
  updateSettings,
  exportBackup,
  restoreBackup,
  BACKUP_TABLES
};

/* ------------------------------------------------------------------ */
/* Self-test: run  node backend/database.js                            */
/* ------------------------------------------------------------------ */
if (require.main === module) {
  console.log('Database file :', dbFile);
  console.log('Foreign keys  :', db.pragma('foreign_keys', { simple: true }) === 1 ? 'ON' : 'OFF');
  console.log('--- Row counts ---');
  BACKUP_TABLES.forEach((t) => {
    const c = db.prepare(`SELECT COUNT(*) AS c FROM ${t}`).get().c;
    console.log(t.padEnd(20), c);
  });
  console.log('Settings      :', JSON.stringify(getSettings()));
  console.log('Database OK');
}