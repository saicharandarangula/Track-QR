'use strict';

/**
 * TrackQR - server.js
 * Express server: serves the frontend AND the REST API from the same address.
 * Open:  http://localhost:5000
 */

const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');

const {
  db,
  dbFile,
  AppError,
  nowIso,
  generateId,
  logActivity,
  getSettings,
  updateSettings,
  exportBackup,
  restoreBackup
} = require('./database');

/* ------------------------------------------------------------------ */
/* Configuration                                                       */
/* ------------------------------------------------------------------ */
const PORT = Number(process.env.PORT) || 5000;
const HOST = process.env.HOST || undefined; // leave empty so localhost always works
const IS_PROD = process.env.NODE_ENV === 'production';
const FRONTEND_DIR = path.resolve(__dirname, '..', 'frontend');

const DEVICE_STATUSES = ['Available', 'In Use', 'Under Maintenance', 'Retired'];
const DEVICE_CONDITIONS = ['New', 'Good', 'Fair', 'Poor', 'Damaged'];
const MAINT_STATUSES = ['Scheduled', 'In Progress', 'Completed'];
const MAINT_TYPES = ['Preventive', 'Repair', 'Inspection', 'Upgrade', 'Cleaning', 'Calibration', 'Other'];
const MOVE_LABELS = { IN: 'Stock-In', OUT: 'Stock-Out', RETURN: 'Stock Return' };

/* ------------------------------------------------------------------ */
/* Validation helpers                                                  */
/* ------------------------------------------------------------------ */
function str(v, label, { required = false, max = 255 } = {}) {
  const s = v === undefined || v === null ? '' : String(v).trim();
  if (required && !s) throw new AppError(`${label} is required.`);
  if (s.length > max) throw new AppError(`${label} must be ${max} characters or fewer.`);
  return s;
}

function num(v, label, { min = 0, max = 1000000000, integer = false, required = false, def = 0 } = {}) {
  if (v === undefined || v === null || String(v).trim() === '') {
    if (required) throw new AppError(`${label} is required.`);
    return def;
  }
  const n = Number(v);
  if (!Number.isFinite(n)) throw new AppError(`${label} must be a number.`);
  if (integer && !Number.isInteger(n)) throw new AppError(`${label} must be a whole number.`);
  if (n < min) throw new AppError(`${label} must be ${min} or more.`);
  if (n > max) throw new AppError(`${label} is too large.`);
  return n;
}

function oneOf(v, list, label, def) {
  if (v === undefined || v === null || v === '') {
    if (def !== undefined) return def;
    throw new AppError(`${label} is required.`);
  }
  if (!list.includes(v)) throw new AppError(`${label} must be one of: ${list.join(', ')}.`);
  return v;
}

function dateStr(v, label) {
  const s = v === undefined || v === null ? '' : String(v).trim();
  if (!s) return '';
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) throw new AppError(`${label} must be a valid date (YYYY-MM-DD).`);
  const d = new Date(`${s}T00:00:00Z`);
  if (Number.isNaN(d.getTime()) || d.toISOString().slice(0, 10) !== s) {
    throw new AppError(`${label} must be a valid date (YYYY-MM-DD).`);
  }
  return s;
}

function parseId(v) {
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1) throw new AppError('Invalid ID.', 400);
  return n;
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function likeClause(cols, term, params) {
  const like = '%' + String(term).replace(/[\\%_]/g, (m) => '\\' + m) + '%';
  cols.forEach(() => params.push(like));
  return '(' + cols.map((c) => `${c} LIKE ? ESCAPE '\\'`).join(' OR ') + ')';
}

function buildOrder(map, sort, order, defCol, defDir) {
  const col = map[sort] || defCol;
  const dir = String(order).toLowerCase() === 'asc' ? 'ASC' : String(order).toLowerCase() === 'desc' ? 'DESC' : defDir;
  return `${col} ${dir}`;
}

function getLimit(v, def = 500) {
  return Math.min(Math.max(parseInt(v, 10) || def, 1), 100000);
}

const wrap = (fn) => (req, res, next) => {
  try {
    const result = fn(req, res, next);
    if (result && typeof result.catch === 'function') result.catch(next);
  } catch (err) {
    next(err);
  }
};

/* ------------------------------------------------------------------ */
/* QR payloads                                                         */
/* ------------------------------------------------------------------ */
const qrDevice = (assetId) => `TQR:D:${assetId}`;
const qrStock = (stockId) => `TQR:S:${stockId}`;

function parseQr(raw) {
  const s = String(raw || '').trim();
  const m = /^TQR:([DS]):(.+)$/i.exec(s);
  if (m) return { kind: m[1].toUpperCase() === 'D' ? 'device' : 'stock', id: m[2].trim() };
  return { kind: null, id: s };
}

/* ------------------------------------------------------------------ */
/* Categories                                                          */
/* ------------------------------------------------------------------ */
const CAT_SELECT = `
  SELECT c.*,
    CASE c.type
      WHEN 'device' THEN (SELECT COUNT(*) FROM devices d WHERE d.category_id = c.id)
      ELSE (SELECT COUNT(*) FROM stock_items s WHERE s.category_id = c.id)
    END AS item_count
  FROM categories c`;

function cleanCategory(b, isUpdate) {
  b = b || {};
  const name = str(b.name, 'Category name', { required: true, max: 60 });
  const prefix = str(b.prefix, 'Prefix', { required: true, max: 6 }).toUpperCase();
  if (!/^[A-Z0-9]{2,6}$/.test(prefix)) {
    throw new AppError('Prefix must be 2 to 6 letters or numbers (no spaces or symbols).');
  }
  const description = str(b.description, 'Description', { max: 200 });
  const type = b.type;
  if (!isUpdate && !['device', 'stock'].includes(type)) {
    throw new AppError('Category type must be device or stock.');
  }
  return { name, prefix, description, type };
}

function assertCategoryUnique(type, name, prefix, excludeId) {
  const byName = db
    .prepare('SELECT id FROM categories WHERE type = ? AND name = ? COLLATE NOCASE AND id != ?')
    .get(type, name, excludeId || 0);
  if (byName) throw new AppError(`A ${type} category named "${name}" already exists.`, 409);
  const byPrefix = db
    .prepare('SELECT id FROM categories WHERE type = ? AND prefix = ? COLLATE NOCASE AND id != ?')
    .get(type, prefix, excludeId || 0);
  if (byPrefix) throw new AppError(`The prefix "${prefix}" is already used by another ${type} category.`, 409);
}

const createCategory = db.transaction((body) => {
  const c = cleanCategory(body, false);
  assertCategoryUnique(c.type, c.name, c.prefix, 0);
  const code = generateId('category', 'CAT');
  const info = db
    .prepare('INSERT INTO categories (category_code, name, prefix, description, type) VALUES (?, ?, ?, ?, ?)')
    .run(code, c.name, c.prefix, c.description, c.type);
  logActivity({
    type: 'Category Created',
    description: `${c.type === 'device' ? 'Device' : 'Stock'} category "${c.name}" (prefix ${c.prefix}) created`,
    itemType: 'category',
    itemCode: code
  });
  return db.prepare(`${CAT_SELECT} WHERE c.id = ?`).get(info.lastInsertRowid);
});

const updateCategory = db.transaction((id, body) => {
  const existing = db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
  if (!existing) throw new AppError('Category not found.', 404);
  if (body && body.type && body.type !== existing.type) throw new AppError('Category type cannot be changed.');
  const c = cleanCategory(body, true);
  assertCategoryUnique(existing.type, c.name, c.prefix, id);
  db.prepare('UPDATE categories SET name = ?, prefix = ?, description = ?, updated_at = ? WHERE id = ?').run(
    c.name,
    c.prefix,
    c.description,
    nowIso(),
    id
  );
  const used = db
    .prepare(
      existing.type === 'device'
        ? 'SELECT COUNT(*) AS n FROM devices WHERE category_id = ?'
        : 'SELECT COUNT(*) AS n FROM stock_items WHERE category_id = ?'
    )
    .get(id).n;
  const parts = [];
  if (existing.name !== c.name) parts.push(`renamed from "${existing.name}" to "${c.name}" (${used} item(s) updated automatically)`);
  if (existing.prefix !== c.prefix) parts.push(`prefix changed from ${existing.prefix} to ${c.prefix} (new items only; existing IDs never change)`);
  if (existing.description !== c.description) parts.push('description updated');
  if (parts.length) {
    logActivity({
      type: 'Category Updated',
      description: `Category ${existing.category_code}: ${parts.join('; ')}`,
      itemType: 'category',
      itemCode: existing.category_code
    });
  }
  return db.prepare(`${CAT_SELECT} WHERE c.id = ?`).get(id);
});

const deleteCategory = db.transaction((id) => {
  const existing = db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
  if (!existing) throw new AppError('Category not found.', 404);
  const used = db
    .prepare(
      existing.type === 'device'
        ? 'SELECT COUNT(*) AS n FROM devices WHERE category_id = ?'
        : 'SELECT COUNT(*) AS n FROM stock_items WHERE category_id = ?'
    )
    .get(id).n;
  if (used > 0) {
    throw new AppError(
      `Cannot delete "${existing.name}" because ${used} ${existing.type === 'device' ? 'device(s)' : 'stock item(s)'} use it. Move or delete them first.`,
      409
    );
  }
  db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  logActivity({
    type: 'Category Deleted',
    description: `${existing.type === 'device' ? 'Device' : 'Stock'} category "${existing.name}" deleted`,
    itemType: 'category',
    itemCode: existing.category_code
  });
});

/* ------------------------------------------------------------------ */
/* Devices                                                             */
/* ------------------------------------------------------------------ */
const DEVICE_SELECT = `
  SELECT d.*, c.name AS category_name, c.prefix AS category_prefix
  FROM devices d JOIN categories c ON c.id = d.category_id`;

const withDeviceQr = (d) => (d ? { ...d, qr_payload: qrDevice(d.asset_id), item_type: 'device' } : d);

function getDevice(id) {
  return withDeviceQr(db.prepare(`${DEVICE_SELECT} WHERE d.id = ?`).get(id));
}

function listDevices(q) {
  const where = [];
  const params = [];
  if (q.q && String(q.q).trim()) {
    where.push(
      likeClause(
        ['d.asset_id', 'd.name', 'd.serial_number', 'd.brand', 'd.model', 'd.location', 'd.assigned_to', 'c.name'],
        String(q.q).trim().slice(0, 100),
        params
      )
    );
  }
  if (q.category_id) {
    where.push('d.category_id = ?');
    params.push(parseId(q.category_id));
  }
  if (q.status) {
    where.push('d.status = ?');
    params.push(String(q.status));
  }
  if (q.condition) {
    where.push('d."condition" = ?');
    params.push(String(q.condition));
  }
  const order = buildOrder(
    {
      asset_id: 'd.asset_id',
      name: 'd.name COLLATE NOCASE',
      category: 'c.name COLLATE NOCASE',
      status: 'd.status',
      condition: 'd."condition"',
      purchase_date: 'd.purchase_date',
      purchase_price: 'd.purchase_price',
      created_at: 'd.created_at'
    },
    q.sort,
    q.order,
    'd.created_at',
    'DESC'
  );
  const sql = `${DEVICE_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${order}, d.id DESC`;
  return db.prepare(sql).all(...params).map(withDeviceQr);
}

function cleanDevice(b) {
  b = b || {};
  if (!b.category_id) throw new AppError('Category is required.');
  return {
    name: str(b.name, 'Device name', { required: true, max: 120 }),
    category_id: parseId(b.category_id),
    serial_number: str(b.serial_number, 'Serial number', { max: 80 }),
    brand: str(b.brand, 'Brand', { max: 80 }),
    model: str(b.model, 'Model', { max: 80 }),
    purchase_date: dateStr(b.purchase_date, 'Purchase date'),
    purchase_price: num(b.purchase_price, 'Purchase price', { min: 0 }),
    location: str(b.location, 'Location', { max: 120 }),
    assigned_to: str(b.assigned_to, 'Assigned employee or department', { max: 120 }),
    condition: oneOf(b.condition, DEVICE_CONDITIONS, 'Condition', 'Good'),
    status: oneOf(b.status, DEVICE_STATUSES, 'Status', 'Available'),
    description: str(b.description, 'Description', { max: 500 })
  };
}

function assertSerialUnique(serial, excludeId) {
  if (!serial) return;
  const dup = db
    .prepare('SELECT asset_id FROM devices WHERE serial_number = ? COLLATE NOCASE AND id != ?')
    .get(serial, excludeId || 0);
  if (dup) throw new AppError(`Serial number "${serial}" is already used by device ${dup.asset_id}.`, 409);
}

const createDevice = db.transaction((body) => {
  const d = cleanDevice(body);
  const cat = db.prepare("SELECT * FROM categories WHERE id = ? AND type = 'device'").get(d.category_id);
  if (!cat) throw new AppError('Please choose a valid device category.');
  assertSerialUnique(d.serial_number, 0);
  const assetId = generateId('device', cat.prefix);
  const info = db
    .prepare(
      `INSERT INTO devices
        (asset_id, name, category_id, serial_number, brand, model, purchase_date, purchase_price,
         location, assigned_to, "condition", status, description)
       VALUES
        (@asset_id, @name, @category_id, @serial_number, @brand, @model, @purchase_date, @purchase_price,
         @location, @assigned_to, @condition, @status, @description)`
    )
    .run({ asset_id: assetId, ...d });
  logActivity({
    type: 'Device Registered',
    description: `Device ${assetId} (${d.name}) registered in category ${cat.name}`,
    itemType: 'device',
    itemCode: assetId
  });
  return info.lastInsertRowid;
});

const DEVICE_FIELDS = [
  'name', 'category_id', 'serial_number', 'brand', 'model', 'purchase_date', 'purchase_price',
  'location', 'assigned_to', 'condition', 'status', 'description'
];

const updateDevice = db.transaction((id, body) => {
  const old = db.prepare('SELECT * FROM devices WHERE id = ?').get(id);
  if (!old) throw new AppError('Device not found.', 404);
  const d = cleanDevice(body);
  const cat = db.prepare("SELECT * FROM categories WHERE id = ? AND type = 'device'").get(d.category_id);
  if (!cat) throw new AppError('Please choose a valid device category.');
  assertSerialUnique(d.serial_number, id);
  const changed = DEVICE_FIELDS.filter((f) => String(old[f]) !== String(d[f]));
  if (changed.length === 0) return id;
  db.prepare(
    `UPDATE devices SET
       name=@name, category_id=@category_id, serial_number=@serial_number, brand=@brand, model=@model,
       purchase_date=@purchase_date, purchase_price=@purchase_price, location=@location,
       assigned_to=@assigned_to, "condition"=@condition, status=@status, description=@description,
       updated_at=@updated_at
     WHERE id=@id`
  ).run({ ...d, updated_at: nowIso(), id });
  logActivity({
    type: 'Device Updated',
    description: `Device ${old.asset_id} (${d.name}) updated: ${changed.join(', ')}`,
    itemType: 'device',
    itemCode: old.asset_id
  });
  return id;
});

const deleteDevice = db.transaction((id) => {
  const old = db.prepare('SELECT * FROM devices WHERE id = ?').get(id);
  if (!old) throw new AppError('Device not found.', 404);
  db.prepare('DELETE FROM devices WHERE id = ?').run(id);
  logActivity({
    type: 'Device Deleted',
    description: `Device ${old.asset_id} (${old.name}) deleted. Its history is kept in the logs.`,
    itemType: 'device',
    itemCode: old.asset_id
  });
});

/* ------------------------------------------------------------------ */
/* Stock                                                               */
/* ------------------------------------------------------------------ */
const STOCK_SELECT = `
  SELECT s.*, c.name AS category_name, c.prefix AS category_prefix,
    CASE
      WHEN s.quantity = 0 THEN 'Out of Stock'
      WHEN s.quantity <= s.min_stock_level THEN 'Low Stock'
      ELSE 'Normal'
    END AS stock_level
  FROM stock_items s JOIN categories c ON c.id = s.category_id`;

const withStockQr = (s) => (s ? { ...s, qr_payload: qrStock(s.stock_id), item_type: 'stock' } : s);

function getStock(id) {
  return withStockQr(db.prepare(`${STOCK_SELECT} WHERE s.id = ?`).get(id));
}

function listStock(q) {
  const where = [];
  const params = [];
  if (q.q && String(q.q).trim()) {
    where.push(
      likeClause(
        ['t.stock_id', 't.name', 't.category_name', 't.supplier', 't.location', 't.description'],
        String(q.q).trim().slice(0, 100),
        params
      )
    );
  }
  if (q.category_id) {
    where.push('t.category_id = ?');
    params.push(parseId(q.category_id));
  }
  if (q.level) {
    const map = { low: 'Low Stock', out: 'Out of Stock', normal: 'Normal' };
    if (!map[q.level]) throw new AppError('Stock level filter must be low, out or normal.');
    where.push('t.stock_level = ?');
    params.push(map[q.level]);
  }
  const order = buildOrder(
    {
      stock_id: 't.stock_id',
      name: 't.name COLLATE NOCASE',
      category: 't.category_name COLLATE NOCASE',
      quantity: 't.quantity',
      unit_price: 't.unit_price',
      updated_at: 't.updated_at'
    },
    q.sort,
    q.order,
    't.updated_at',
    'DESC'
  );
  const sql = `SELECT t.* FROM (${STOCK_SELECT}) t ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ${order}, t.id DESC`;
  return db.prepare(sql).all(...params).map(withStockQr);
}

function cleanStock(b, isCreate) {
  b = b || {};
  if (!b.category_id) throw new AppError('Category is required.');
  const out = {
    name: str(b.name, 'Item name', { required: true, max: 120 }),
    category_id: parseId(b.category_id),
    description: str(b.description, 'Description', { max: 500 }),
    unit: str(b.unit, 'Unit', { max: 20 }) || 'pcs',
    unit_price: num(b.unit_price, 'Unit price', { min: 0 }),
    min_stock_level: num(b.min_stock_level, 'Minimum stock level', {
      min: 0,
      integer: true,
      def: getSettings().default_low_stock
    }),
    location: str(b.location, 'Location', { max: 120 }),
    supplier: str(b.supplier, 'Supplier', { max: 120 })
  };
  if (isCreate) out.quantity = num(b.quantity, 'Quantity', { min: 0, integer: true, def: 0 });
  return out;
}

const insertTxn = db.prepare(`
  INSERT INTO stock_transactions
    (transaction_id, stock_item_id, stock_id, item_name, movement_type, quantity, balance_after, person, remarks, request_key)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`);

const createStock = db.transaction((body) => {
  const s = cleanStock(body, true);
  const cat = db.prepare("SELECT * FROM categories WHERE id = ? AND type = 'stock'").get(s.category_id);
  if (!cat) throw new AppError('Please choose a valid stock category.');
  const stockId = generateId('stock', cat.prefix);
  const info = db
    .prepare(
      `INSERT INTO stock_items
        (stock_id, name, category_id, description, quantity, unit, unit_price, min_stock_level, location, supplier)
       VALUES
        (@stock_id, @name, @category_id, @description, @quantity, @unit, @unit_price, @min_stock_level, @location, @supplier)`
    )
    .run({ stock_id: stockId, ...s });
  logActivity({
    type: 'Stock Created',
    description: `Stock item ${stockId} (${s.name}) created with ${s.quantity} ${s.unit}`,
    itemType: 'stock',
    itemCode: stockId
  });
  if (s.quantity > 0) {
    insertTxn.run(generateId('transaction', 'TXN'), info.lastInsertRowid, stockId, s.name, 'IN', s.quantity, s.quantity, 'System', 'Opening stock', null);
  }
  return info.lastInsertRowid;
});

const STOCK_FIELDS = ['name', 'category_id', 'description', 'unit', 'unit_price', 'min_stock_level', 'location', 'supplier'];

const updateStock = db.transaction((id, body) => {
  const old = db.prepare('SELECT * FROM stock_items WHERE id = ?').get(id);
  if (!old) throw new AppError('Stock item not found.', 404);
  const s = cleanStock(body, false); // quantity is changed only through stock movements
  const cat = db.prepare("SELECT * FROM categories WHERE id = ? AND type = 'stock'").get(s.category_id);
  if (!cat) throw new AppError('Please choose a valid stock category.');
  const changed = STOCK_FIELDS.filter((f) => String(old[f]) !== String(s[f]));
  if (changed.length === 0) return id;
  db.prepare(
    `UPDATE stock_items SET
       name=@name, category_id=@category_id, description=@description, unit=@unit, unit_price=@unit_price,
       min_stock_level=@min_stock_level, location=@location, supplier=@supplier, updated_at=@updated_at
     WHERE id=@id`
  ).run({ ...s, updated_at: nowIso(), id });
  if (old.name !== s.name) {
    db.prepare('UPDATE stock_transactions SET item_name = ? WHERE stock_item_id = ?').run(s.name, id);
  }
  logActivity({
    type: 'Stock Updated',
    description: `Stock item ${old.stock_id} (${s.name}) updated: ${changed.join(', ')}`,
    itemType: 'stock',
    itemCode: old.stock_id
  });
  return id;
});

const deleteStock = db.transaction((id) => {
  const old = db.prepare('SELECT * FROM stock_items WHERE id = ?').get(id);
  if (!old) throw new AppError('Stock item not found.', 404);
  db.prepare('DELETE FROM stock_items WHERE id = ?').run(id);
  logActivity({
    type: 'Stock Deleted',
    description: `Stock item ${old.stock_id} (${old.name}) deleted. Its transaction history is kept.`,
    itemType: 'stock',
    itemCode: old.stock_id
  });
});

const moveStock = db.transaction((id, body) => {
  body = body || {};
  const type = String(body.type || '').toUpperCase();
  if (!MOVE_LABELS[type]) throw new AppError('Movement type must be IN, OUT or RETURN.');
  const quantity = num(body.quantity, 'Quantity', { min: 1, integer: true, required: true, max: 100000000 });
  const person = str(body.person, 'Person responsible', { required: true, max: 120 });
  const remarks = str(body.remarks, 'Remarks', { max: 300 });
  const requestKey = body.request_key ? str(body.request_key, 'Request key', { max: 100 }) : null;

  const item = db.prepare('SELECT * FROM stock_items WHERE id = ?').get(id);
  if (!item) throw new AppError('Stock item not found.', 404);

  if (requestKey) {
    const dup = db.prepare('SELECT * FROM stock_transactions WHERE request_key = ?').get(requestKey);
    if (dup) return { duplicate: true, transaction: dup, item: getStock(id) };
  }

  let newQty = item.quantity;
  if (type === 'OUT') {
    if (quantity > item.quantity) {
      throw new AppError(`Not enough stock. Only ${item.quantity} ${item.unit} available.`, 409);
    }
    newQty -= quantity;
  } else {
    newQty += quantity;
  }

  db.prepare('UPDATE stock_items SET quantity = ?, updated_at = ? WHERE id = ?').run(newQty, nowIso(), id);
  const txnId = generateId('transaction', 'TXN');
  insertTxn.run(txnId, id, item.stock_id, item.name, type, quantity, newQty, person, remarks, requestKey);
  logActivity({
    type: 'Stock Movement',
    description: `${MOVE_LABELS[type]}: ${quantity} ${item.unit} of ${item.name} (${item.stock_id}) by ${person}. Balance: ${newQty}`,
    itemType: 'stock',
    itemCode: item.stock_id,
    user: person
  });
  return {
    duplicate: false,
    transaction: db.prepare('SELECT * FROM stock_transactions WHERE transaction_id = ?').get(txnId),
    item: getStock(id)
  };
});

function listTransactions(q) {
  const where = [];
  const params = [];
  if (q.stock_id) {
    where.push('stock_item_id = ?');
    params.push(parseId(q.stock_id));
  }
  if (q.type) {
    where.push('movement_type = ?');
    params.push(String(q.type).toUpperCase());
  }
  if (q.q && String(q.q).trim()) {
    where.push(likeClause(['transaction_id', 'stock_id', 'item_name', 'person', 'remarks'], String(q.q).trim().slice(0, 100), params));
  }
  const sql = `SELECT * FROM stock_transactions ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT ${getLimit(q.limit, 500)}`;
  return db.prepare(sql).all(...params);
}

/* ------------------------------------------------------------------ */
/* Maintenance                                                         */
/* ------------------------------------------------------------------ */
const MAINT_SELECT = `
  SELECT m.*, d.status AS device_status
  FROM maintenance m LEFT JOIN devices d ON d.id = m.device_id`;

function listMaintenance(q) {
  const where = [];
  const params = [];
  if (q.status) {
    where.push('m.status = ?');
    params.push(String(q.status));
  }
  if (q.device_id) {
    where.push('m.device_id = ?');
    params.push(parseId(q.device_id));
  }
  if (q.q && String(q.q).trim()) {
    where.push(
      likeClause(
        ['m.ticket_id', 'm.device_asset_id', 'm.device_name', 'm.technician', 'm.notes', 'm.maintenance_type'],
        String(q.q).trim().slice(0, 100),
        params
      )
    );
  }
  const sql = `${MAINT_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY m.id DESC LIMIT ${getLimit(q.limit, 1000)}`;
  return db.prepare(sql).all(...params);
}

function cleanMaintenance(b) {
  b = b || {};
  const status = oneOf(b.status, MAINT_STATUSES, 'Status', 'Scheduled');
  let completion = dateStr(b.completion_date, 'Completion date');
  if (status === 'Completed') {
    if (!completion) completion = todayStr();
  } else {
    completion = '';
  }
  return {
    maintenance_type: oneOf(b.maintenance_type, MAINT_TYPES, 'Maintenance type', 'Repair'),
    scheduled_date: dateStr(b.scheduled_date, 'Scheduled date'),
    completion_date: completion,
    technician: str(b.technician, 'Technician', { max: 120 }),
    cost: num(b.cost, 'Cost', { min: 0 }),
    notes: str(b.notes, 'Notes', { max: 1000 }),
    status
  };
}

function setDeviceStatus(dev, status, reason) {
  db.prepare('UPDATE devices SET status = ?, updated_at = ? WHERE id = ?').run(status, nowIso(), dev.id);
  logActivity({
    type: 'Device Updated',
    description: `Device ${dev.asset_id} status changed to ${status} (${reason})`,
    itemType: 'device',
    itemCode: dev.asset_id
  });
}

function syncDeviceForTicket(deviceId, oldStatus, newStatus) {
  if (!deviceId) return;
  const dev = db.prepare('SELECT * FROM devices WHERE id = ?').get(deviceId);
  if (!dev) return;
  if (newStatus === 'In Progress' && dev.status !== 'Under Maintenance') {
    setDeviceStatus(dev, 'Under Maintenance', 'maintenance started');
  } else if (oldStatus === 'In Progress' && newStatus !== 'In Progress') {
    const others = db
      .prepare("SELECT COUNT(*) AS n FROM maintenance WHERE device_id = ? AND status = 'In Progress'")
      .get(deviceId).n;
    if (others === 0 && dev.status === 'Under Maintenance') {
      setDeviceStatus(dev, 'Available', 'maintenance finished');
    }
  }
}

const createMaintenance = db.transaction((body) => {
  body = body || {};
  if (!body.device_id) throw new AppError('Please select a device.');
  const dev = db.prepare('SELECT * FROM devices WHERE id = ?').get(parseId(body.device_id));
  if (!dev) throw new AppError('The selected device no longer exists.', 404);
  const m = cleanMaintenance(body);
  const ticketId = generateId('maintenance', 'MNT');
  const info = db
    .prepare(
      `INSERT INTO maintenance
        (ticket_id, device_id, device_asset_id, device_name, maintenance_type, scheduled_date,
         completion_date, technician, cost, notes, status)
       VALUES
        (@ticket_id, @device_id, @device_asset_id, @device_name, @maintenance_type, @scheduled_date,
         @completion_date, @technician, @cost, @notes, @status)`
    )
    .run({ ticket_id: ticketId, device_id: dev.id, device_asset_id: dev.asset_id, device_name: dev.name, ...m });
  logActivity({
    type: 'Maintenance Created',
    description: `Maintenance ticket ${ticketId} (${m.maintenance_type}) created for ${dev.asset_id} (${dev.name})`,
    itemType: 'maintenance',
    itemCode: ticketId
  });
  syncDeviceForTicket(dev.id, null, m.status);
  return info.lastInsertRowid;
});

const updateMaintenance = db.transaction((id, body) => {
  const old = db.prepare('SELECT * FROM maintenance WHERE id = ?').get(id);
  if (!old) throw new AppError('Maintenance ticket not found.', 404);
  const m = cleanMaintenance(body);
  db.prepare(
    `UPDATE maintenance SET
       maintenance_type=@maintenance_type, scheduled_date=@scheduled_date, completion_date=@completion_date,
       technician=@technician, cost=@cost, notes=@notes, status=@status, updated_at=@updated_at
     WHERE id=@id`
  ).run({ ...m, updated_at: nowIso(), id });
  logActivity({
    type: 'Maintenance Updated',
    description:
      old.status !== m.status
        ? `Ticket ${old.ticket_id} (${old.device_asset_id}) status changed from ${old.status} to ${m.status}`
        : `Ticket ${old.ticket_id} (${old.device_asset_id}) updated`,
    itemType: 'maintenance',
    itemCode: old.ticket_id
  });
  syncDeviceForTicket(old.device_id, old.status, m.status);
  return id;
});

const deleteMaintenance = db.transaction((id) => {
  const old = db.prepare('SELECT * FROM maintenance WHERE id = ?').get(id);
  if (!old) throw new AppError('Maintenance ticket not found.', 404);
  db.prepare('DELETE FROM maintenance WHERE id = ?').run(id);
  logActivity({
    type: 'Maintenance Deleted',
    description: `Maintenance ticket ${old.ticket_id} (${old.device_asset_id}) deleted`,
    itemType: 'maintenance',
    itemCode: old.ticket_id
  });
  syncDeviceForTicket(old.device_id, old.status, null);
});

/* ------------------------------------------------------------------ */
/* Activity logs                                                       */
/* ------------------------------------------------------------------ */
function listLogs(q) {
  const where = [];
  const params = [];
  if (q.type) {
    where.push('activity_type = ?');
    params.push(String(q.type));
  }
  if (q.item_type) {
    where.push('item_type = ?');
    params.push(String(q.item_type));
  }
  if (q.q && String(q.q).trim()) {
    where.push(likeClause(['description', 'item_code', 'activity_type', 'user_name'], String(q.q).trim().slice(0, 100), params));
  }
  if (q.from) {
    where.push('substr(created_at, 1, 10) >= ?');
    params.push(dateStr(q.from, 'From date'));
  }
  if (q.to) {
    where.push('substr(created_at, 1, 10) <= ?');
    params.push(dateStr(q.to, 'To date'));
  }
  const sql = `SELECT * FROM activity_logs ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT ${getLimit(q.limit, 500)}`;
  return db.prepare(sql).all(...params);
}

/* ------------------------------------------------------------------ */
/* CSV export                                                          */
/* ------------------------------------------------------------------ */
function toCsv(rows, columns) {
  const esc = (v) => {
    let s = v === null || v === undefined ? '' : String(v);
    if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // stops spreadsheet formula injection
    if (/[",\r\n]/.test(s)) s = '"' + s.replace(/"/g, '""') + '"';
    return s;
  };
  const lines = [columns.map((c) => esc(c[1])).join(',')];
  rows.forEach((r) => lines.push(columns.map((c) => esc(r[c[0]])).join(',')));
  return '\uFEFF' + lines.join('\r\n');
}

const EXPORTS = {
  devices: {
    rows: (q) => listDevices(q),
    cols: [
      ['asset_id', 'Asset ID'], ['name', 'Device Name'], ['category_name', 'Category'],
      ['serial_number', 'Serial Number'], ['brand', 'Brand'], ['model', 'Model'],
      ['purchase_date', 'Purchase Date'], ['purchase_price', 'Purchase Price'], ['location', 'Location'],
      ['assigned_to', 'Assigned To'], ['condition', 'Condition'], ['status', 'Status'],
      ['description', 'Description']
    ]
  },
  stock: {
    rows: (q) => listStock(q),
    cols: [
      ['stock_id', 'Stock ID'], ['name', 'Item Name'], ['category_name', 'Category'],
      ['description', 'Description'], ['quantity', 'Quantity'], ['unit', 'Unit'],
      ['unit_price', 'Unit Price'], ['min_stock_level', 'Minimum Stock'], ['stock_level', 'Stock Level'],
      ['location', 'Location'], ['supplier', 'Supplier'], ['updated_at', 'Last Updated']
    ]
  },
  transactions: {
    rows: (q) => listTransactions({ ...q, limit: 100000 }),
    cols: [
      ['transaction_id', 'Transaction ID'], ['stock_id', 'Stock ID'], ['item_name', 'Item Name'],
      ['movement_type', 'Movement'], ['quantity', 'Quantity'], ['balance_after', 'Balance After'],
      ['created_at', 'Date and Time'], ['person', 'Person Responsible'], ['remarks', 'Remarks']
    ]
  },
  maintenance: {
    rows: (q) => listMaintenance({ ...q, limit: 100000 }),
    cols: [
      ['ticket_id', 'Ticket ID'], ['device_asset_id', 'Asset ID'], ['device_name', 'Device'],
      ['maintenance_type', 'Type'], ['scheduled_date', 'Scheduled Date'], ['completion_date', 'Completion Date'],
      ['technician', 'Technician'], ['cost', 'Cost'], ['status', 'Status'], ['notes', 'Notes']
    ]
  },
  logs: {
    rows: (q) => listLogs({ ...q, limit: 100000 }),
    cols: [
      ['created_at', 'Date and Time'], ['activity_type', 'Activity'], ['description', 'Description'],
      ['item_type', 'Item Type'], ['item_code', 'Related Item'], ['user_name', 'User']
    ]
  },
  categories: {
    rows: (q) => db.prepare(`${CAT_SELECT} ${q.type ? 'WHERE c.type = ?' : ''} ORDER BY c.type, c.name`).all(...(q.type ? [String(q.type)] : [])),
    cols: [
      ['category_code', 'Category ID'], ['name', 'Name'], ['prefix', 'Prefix'], ['type', 'Type'],
      ['description', 'Description'], ['item_count', 'Items']
    ]
  }
};

/* ------------------------------------------------------------------ */
/* Express app                                                         */
/* ------------------------------------------------------------------ */
const app = express();
app.disable('x-powered-by');

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'blob:'],
        mediaSrc: ["'self'", 'blob:'],
        connectSrc: ["'self'"],
        fontSrc: ["'self'", 'data:'],
        workerSrc: ["'self'", 'blob:'],
        manifestSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'self'"]
      }
    },
    hsts: IS_PROD
  })
);

app.use((req, res, next) => {
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=()');
  next();
});

const allowedOrigins = new Set([
  `http://localhost:${PORT}`,
  `http://127.0.0.1:${PORT}`,
  'http://localhost',
  'https://localhost',
  'capacitor://localhost',
  'ionic://localhost',
  ...(process.env.CORS_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean)
]);
app.use(
  cors({
    origin(origin, cb) {
      cb(null, !origin || allowedOrigins.has(origin));
    }
  })
);

app.use(express.json({ limit: '25mb' }));

/* ------------------------------ API ------------------------------- */
const api = express.Router();
api.use((req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

api.get('/health', (req, res) => {
  try {
    db.prepare('SELECT 1').get();
    res.json({ status: 'ok', database: 'connected', time: new Date().toISOString(), version: '1.0.0' });
  } catch (err) {
    console.error('Health check failed:', err.message);
    res.status(503).json({ status: 'error', database: 'unavailable' });
  }
});

/* Dashboard */
api.get('/dashboard/stats', wrap((req, res) => {
  const dv = db.prepare(`
    SELECT COUNT(*) AS total,
      COALESCE(SUM(status = 'Available'), 0) AS available,
      COALESCE(SUM(status = 'In Use'), 0) AS in_use,
      COALESCE(SUM(status = 'Under Maintenance'), 0) AS under_maintenance,
      COALESCE(SUM(status = 'Retired'), 0) AS retired
    FROM devices`).get();
  const st = db.prepare(`
    SELECT COUNT(*) AS skus,
      COALESCE(SUM(quantity), 0) AS units,
      COALESCE(SUM(quantity > 0 AND quantity <= min_stock_level), 0) AS low,
      COALESCE(SUM(quantity = 0), 0) AS out
    FROM stock_items`).get();
  const pending = db.prepare("SELECT COUNT(*) AS n FROM maintenance WHERE status <> 'Completed'").get().n;
  res.json({
    total_devices: dv.total,
    available_devices: dv.available,
    in_use_devices: dv.in_use,
    maintenance_devices: dv.under_maintenance,
    retired_devices: dv.retired,
    total_stock_skus: st.skus,
    total_stock_units: st.units,
    low_stock_alerts: st.low,
    out_of_stock_alerts: st.out,
    pending_maintenance: pending,
    recent_activities: db.prepare('SELECT * FROM activity_logs ORDER BY id DESC LIMIT 10').all(),
    recent_transactions: db.prepare('SELECT * FROM stock_transactions ORDER BY id DESC LIMIT 10').all()
  });
}));

/* Categories */
api.get('/categories', wrap((req, res) => {
  const type = req.query.type;
  if (type && !['device', 'stock'].includes(type)) throw new AppError('Category type must be device or stock.');
  const rows = type
    ? db.prepare(`${CAT_SELECT} WHERE c.type = ? ORDER BY c.name COLLATE NOCASE`).all(type)
    : db.prepare(`${CAT_SELECT} ORDER BY c.type, c.name COLLATE NOCASE`).all();
  res.json(rows);
}));
api.post('/categories', wrap((req, res) => res.status(201).json(createCategory(req.body))));
api.put('/categories/:id', wrap((req, res) => res.json(updateCategory(parseId(req.params.id), req.body))));
api.delete('/categories/:id', wrap((req, res) => {
  deleteCategory(parseId(req.params.id));
  res.json({ ok: true });
}));

/* Devices */
api.get('/devices', wrap((req, res) => res.json(listDevices(req.query))));
api.get('/devices/:id', wrap((req, res) => {
  const id = parseId(req.params.id);
  const device = getDevice(id);
  if (!device) throw new AppError('Device not found.', 404);
  device.maintenance_history = db.prepare('SELECT * FROM maintenance WHERE device_id = ? ORDER BY id DESC').all(id);
  device.activity_history = db
    .prepare("SELECT * FROM activity_logs WHERE item_type = 'device' AND item_code = ? ORDER BY id DESC LIMIT 100")
    .all(device.asset_id);
  res.json(device);
}));
api.post('/devices', wrap((req, res) => res.status(201).json(getDevice(createDevice(req.body)))));
api.put('/devices/:id', wrap((req, res) => {
  const id = parseId(req.params.id);
  updateDevice(id, req.body);
  res.json(getDevice(id));
}));
api.delete('/devices/:id', wrap((req, res) => {
  deleteDevice(parseId(req.params.id));
  res.json({ ok: true });
}));

/* Stock (the "transactions" route must come before "/stock/:id") */
api.get('/stock/transactions', wrap((req, res) => res.json(listTransactions(req.query))));
api.get('/stock', wrap((req, res) => res.json(listStock(req.query))));
api.get('/stock/:id', wrap((req, res) => {
  const id = parseId(req.params.id);
  const item = getStock(id);
  if (!item) throw new AppError('Stock item not found.', 404);
  item.transactions = db.prepare('SELECT * FROM stock_transactions WHERE stock_item_id = ? ORDER BY id DESC LIMIT 100').all(id);
  res.json(item);
}));
api.post('/stock', wrap((req, res) => res.status(201).json(getStock(createStock(req.body)))));
api.put('/stock/:id', wrap((req, res) => {
  const id = parseId(req.params.id);
  updateStock(id, req.body);
  res.json(getStock(id));
}));
api.delete('/stock/:id', wrap((req, res) => {
  deleteStock(parseId(req.params.id));
  res.json({ ok: true });
}));
api.post('/stock/:id/movement', wrap((req, res) => {
  const result = moveStock(parseId(req.params.id), req.body);
  res.status(result.duplicate ? 200 : 201).json(result);
}));

/* Maintenance */
api.get('/maintenance', wrap((req, res) => res.json(listMaintenance(req.query))));
api.post('/maintenance', wrap((req, res) => {
  const id = createMaintenance(req.body);
  res.status(201).json(db.prepare(`${MAINT_SELECT} WHERE m.id = ?`).get(id));
}));
api.put('/maintenance/:id', wrap((req, res) => {
  const id = parseId(req.params.id);
  updateMaintenance(id, req.body);
  res.json(db.prepare(`${MAINT_SELECT} WHERE m.id = ?`).get(id));
}));
api.delete('/maintenance/:id', wrap((req, res) => {
  deleteMaintenance(parseId(req.params.id));
  res.json({ ok: true });
}));

/* Logs */
api.get('/logs/types', wrap((req, res) => {
  res.json(db.prepare('SELECT DISTINCT activity_type FROM activity_logs ORDER BY activity_type').all().map((r) => r.activity_type));
}));
api.get('/logs', wrap((req, res) => res.json(listLogs(req.query))));

/* Settings */
api.get('/settings', wrap((req, res) => res.json(getSettings())));
api.put('/settings', wrap((req, res) => {
  const before = getSettings();
  const after = updateSettings(req.body);
  const changed = Object.keys(after).filter((k) => String(before[k]) !== String(after[k]));
  if (changed.length) {
    logActivity({
      type: 'Settings Changed',
      description: `Settings changed: ${changed.join(', ')}`,
      itemType: 'settings'
    });
  }
  res.json(after);
}));

/* QR lookup */
api.get('/qr/lookup/:code', wrap((req, res) => {
  const raw = String(req.params.code || '').trim();
  if (!raw || raw.length > 150) throw new AppError('This QR code is not recognised by TrackQR.', 404);
  const { kind, id } = parseQr(raw);
  const shouldLog = req.query.log !== 'false';

  let device = null;
  let stock = null;
  if (kind !== 'stock') {
    const d = db.prepare('SELECT id FROM devices WHERE asset_id = ? COLLATE NOCASE').get(id);
    if (d) device = getDevice(d.id);
  }
  if (kind !== 'device') {
    const s = db.prepare('SELECT id FROM stock_items WHERE stock_id = ? COLLATE NOCASE').get(id);
    if (s) stock = getStock(s.id);
  }
  if (device && stock) {
    throw new AppError('This code matches both a device and a stock item. Please scan the QR tag again.', 409);
  }
  if (!device && !stock) throw new AppError('This QR code is not recognised by TrackQR.', 404);

  const found = device || stock;
  const type = device ? 'device' : 'stock';
  const code = device ? device.asset_id : stock.stock_id;
  if (shouldLog) {
    logActivity({
      type: 'QR Scan',
      description: `QR scanned: ${type} ${code} (${found.name})`,
      itemType: type,
      itemCode: code
    });
  }
  res.json({ type, item: found });
}));

/* Backup and restore */
api.get('/backup/export', wrap((req, res) => {
  const data = exportBackup();
  logActivity({ type: 'Backup Exported', description: 'Full database backup exported', itemType: 'system' });
  const name = `trackqr-backup-${new Date().toISOString().slice(0, 10)}.json`;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
  res.send(JSON.stringify(data, null, 2));
}));

api.post('/backup/restore', wrap((req, res) => {
  if (!req.body || req.body.confirm !== true) {
    throw new AppError('Please confirm the restore. All current data will be replaced.');
  }
  const counts = restoreBackup(req.body.backup);
  logActivity({
    type: 'Backup Restored',
    description: `Database restored from backup (${counts.devices} devices, ${counts.stock_items} stock items, ${counts.categories} categories)`,
    itemType: 'system'
  });
  res.json({ ok: true, counts });
}));

/* CSV export */
api.get('/export/:kind', wrap((req, res) => {
  const kind = String(req.params.kind || '').replace(/\.csv$/i, '');
  const def = EXPORTS[kind];
  if (!def) throw new AppError('Unknown report type.', 404);
  const csv = toCsv(def.rows(req.query), def.cols);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="trackqr-${kind}-${todayStr()}.csv"`);
  res.send(csv);
}));

api.use((req, res) => res.status(404).json({ error: 'API endpoint not found.' }));
app.use('/api', api);

/* --------------------------- Frontend ----------------------------- */
app.use(
  express.static(FRONTEND_DIR, {
    index: 'index.html',
    setHeaders(res, filePath) {
      const base = path.basename(filePath);
      if (base === 'sw.js' || base === 'index.html' || base === 'manifest.json') {
        res.setHeader('Cache-Control', 'no-cache');
      }
    }
  })
);

app.get('*', (req, res) => {
  if (path.extname(req.path)) return res.status(404).send('File not found');
  const index = path.join(FRONTEND_DIR, 'index.html');
  if (!fs.existsSync(index)) return res.status(404).send('Frontend not found. Check the "frontend" folder.');
  res.sendFile(index);
});

/* --------------------------- Error handler ------------------------- */
function friendlyConstraint(err) {
  const m = String(err.message || '');
  if (err.code === 'SQLITE_CONSTRAINT_TRIGGER') return m;
  if (m.includes('serial_number') || m.includes('idx_devices_serial')) return 'A device with this serial number already exists.';
  if (m.includes('categories.type, categories.name')) return 'A category with this name already exists for this type.';
  if (m.includes('categories.type, categories.prefix')) return 'A category with this prefix already exists for this type.';
  if (m.includes('FOREIGN KEY')) return 'This record is linked to other data and cannot be changed or deleted.';
  if (m.includes('CHECK')) return 'One of the values is not allowed (for example a negative number).';
  return 'This change conflicts with existing data.';
}

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  if (err instanceof AppError) return res.status(err.status).json({ error: err.message });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'The request contained invalid JSON.' });
  if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'The uploaded data is too large.' });
  if (err && typeof err.code === 'string' && err.code.startsWith('SQLITE_CONSTRAINT')) {
    console.error('Constraint error:', err.message);
    return res.status(409).json({ error: friendlyConstraint(err) });
  }
  console.error('Unexpected error:', err);
  res.status(500).json({ error: 'Something went wrong on the server. Please try again.' });
});

/* ------------------------------ Start ------------------------------ */
const server = app.listen(PORT, HOST, () => {
  console.log('');
  console.log('  TrackQR is running');
  console.log(`  Open in browser : http://localhost:${PORT}`);
  console.log(`  Health check    : http://localhost:${PORT}/api/health`);
  console.log(`  Database file   : ${dbFile}`);
  console.log('  Press Ctrl + C to stop the server');
  console.log('');
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\n  Port ${PORT} is already in use.`);
    console.error('  TrackQR may already be running in another terminal. Close that one (Ctrl + C),');
    console.error('  or change PORT in the .env file, then start again.\n');
  } else {
    console.error('Server error:', err.message);
  }
  process.exit(1);
});

function shutdown() {
  console.log('\nStopping TrackQR...');
  server.close(() => {
    try { db.close(); } catch (e) { /* ignore */ }
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 2000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);